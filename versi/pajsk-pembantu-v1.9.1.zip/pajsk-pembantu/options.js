/* PAJSK Pembantu — halaman tetapan */
(function () {
  'use strict';
  const PP = globalThis.PP;
  const $ = (id) => document.getElementById(id);
  const store = {
    get: (k) => new Promise((r) => chrome.storage.local.get(k, r)),
    set: (o) => new Promise((r) => chrome.storage.local.set(o, r)),
    remove: (k) => new Promise((r) => chrome.storage.local.remove(k, r))
  };

  const KOMITMEN = ['MENUNJUKKAN KEPIMPINAN', 'MENGURUS AKTIVITI', 'MENYEDIA PERALATAN', 'MEMBANTU GURU ATAU RAKAN', 'MENGEMAS PERALATAN',
    'MEMBERSIH KAWASAN', 'MENEPATI WAKTU', 'MENUNJUKKAN MINAT', 'MENUNJUKKAN KESUNGGUHAN', 'MENGIKUT ARAHAN', 'MENCUBA', 'MEMBERI KERJASAMA',
    'MANA-MANA NILAI MURNI YANG BOLEH DIPERHATIKAN'];
  const KHIDMAT = ['Didaftarkan sebagai atlet / peserta program, pertandingan, karnival, kursus',
    'Kemahiran khusus — aspek teknikal (pengadil, jurulatih pasukan, dll.)',
    'Terlibat dalam aktiviti seperti persembahan selingan',
    'Membantu menjayakan aktiviti (perbarisan, persembahan, kumpulan sorak, dll.)'];

  $('ver').textContent = chrome.runtime.getManifest().version;

  function status(id, msg, ok) {
    const e = $(id); e.textContent = msg; e.className = 'status' + (e.classList.contains('inline') ? ' inline' : '') + (ok === false ? ' err' : ' ok');
    if (e.classList.contains('inline')) setTimeout(() => { if (e.textContent === msg) e.textContent = ''; }, 3000);
  }
  // kekalkan kelas inline
  ['defStatus', 'mapStatus', 'setStatus'].forEach((i) => $(i).classList.add('inline'));

  // ------------------------------------------------------------------
  // Import
  // ------------------------------------------------------------------
  async function importRows(rows, fileName) {
    try {
      const r = PP.rowsToStudents(rows);
      if (!r.count) throw new Error('Tiada baris murid yang sah (No. KP sekurang-kurangnya 6 digit).');
      let students = r.students;
      if ($('appendMode').checked) {
        const d = await store.get(['pp_students']);
        students = Object.assign({}, d.pp_students || {}, r.students);
      }
      const meta = { fileName, count: Object.keys(students).length, importedAt: Date.now(), columns: r.columns };
      await store.set({ pp_students: students, pp_meta: meta });
      status('importStatus', '✓ ' + r.count + ' murid diimport dari "' + fileName + '". Lajur dikenali: ' + r.columns.map(colName).join(', '), true);
      await renderPreview();
      await renderMatches();
    } catch (e) {
      status('importStatus', '✖ ' + e.message, false);
    }
  }

  function colName(c) {
    const [k, f] = c.split('.');
    if (!f) return ({ ic: 'No. KP', nama: 'Nama', kelas: 'Kelas' })[k] || k;
    if (k === 'EKSTRA') return 'Ekstra (Perkhidmatan)';
    return PP.KOMPONEN[k].label.split(' ')[0] + ' – ' + PP.FIELD_LABEL[f];
  }

  $('file').addEventListener('change', async (ev) => {
    const f = ev.target.files[0];
    if (!f) return;
    try {
      const buf = await f.arrayBuffer();
      let rows;
      if (/\.(csv|txt)$/i.test(f.name)) {
        rows = PP.parseCSV(new TextDecoder('utf-8').decode(buf).replace(/^﻿/, ''));
      } else {
        const wb = XLSX.read(buf, { type: 'array', raw: true, cellText: true });
        const ws = wb.Sheets[wb.SheetNames[0]];
        rows = XLSX.utils.sheet_to_json(ws, { header: 1, raw: false, defval: '' });
      }
      await importRows(rows, f.name);
    } catch (e) {
      status('importStatus', '✖ Fail tidak dapat dibaca: ' + e.message, false);
    }
    ev.target.value = '';
  });

  $('btnPaste').onclick = () => { $('pasteBox').classList.toggle('hidden'); $('pasteArea').focus(); };
  $('btnPasteOk').onclick = () => {
    const t = $('pasteArea').value;
    if (!t.trim()) return;
    importRows(PP.parseCSV(t), 'Tampalan ' + new Date().toLocaleString('ms-MY'));
  };
  $('btnClear').onclick = async () => {
    if (!confirm('Padam semua data murid yang diimport?')) return;
    await store.remove(['pp_students', 'pp_meta']);
    status('importStatus', 'Data murid dipadam.', true);
    renderPreview(); renderMatches();
  };
  $('btnTemplate').onclick = () => {
    const head = ['IC', 'Nama'];
    const sample = ['120101101234', 'CONTOH NAMA MURID'];
    const sampleVals = {
      KELAB: ['KELAB KOPERASI', 'AHLI AKTIF', 'SEKOLAH:3', '', '7;8;10;12', '1', '12'],
      UNIFORM: ['PASUKAN KADET POLIS', 'AHLI AKTIF', 'SEKOLAH:3; ZON/DAERAH:1', 'ZON/DAERAH:JOHAN', '7;8;10;12', '4', '10'],
      SUKAN: ['KELAB CATUR', 'AHLI AKTIF', 'SEKOLAH:2', '', '7;8;10;12', '1', '12']
    };
    const names = { KELAB: 'Kelab', UNIFORM: 'Uniform', SUKAN: 'Sukan' };
    PP.MAIN_KEYS.forEach((k) => {
      head.push(PP.KOMPONEN[k].label.replace(' & ', '/'), 'Jawatan ' + names[k], 'Pelibatan ' + names[k], 'Pencapaian ' + names[k], 'Komitmen ' + names[k], 'Khidmat ' + names[k], 'Kehadiran ' + names[k]);
      sample.push(...sampleVals[k]);
    });
    head.push('Jawatan Khas', 'Anugerah Khas', 'Khidmat Masyarakat', 'NILAM', 'TIMSS PISA'); sample.push('Pengawas Biasa', '', 'KEJIRANAN:1; ALAM SEKITAR:1', '3', '');
    const csv = '\ufeff' + PP.toCSV([head, sample]);
    const a = document.createElement('a');
    a.href = URL.createObjectURL(new Blob([csv], { type: 'text/csv;charset=utf-8' }));
    a.download = 'templat_pajsk_pembantu.csv';
    a.click();
  };

  async function renderPreview() {
    const d = await store.get(['pp_students', 'pp_meta']);
    const s = d.pp_students || {};
    const t = $('preview');
    t.innerHTML = '';
    const ics = Object.keys(s);
    if (!ics.length) { $('importStatus').textContent || status('importStatus', 'Belum ada data diimport.', true); return; }
    if (!$('importStatus').textContent && d.pp_meta) status('importStatus', d.pp_meta.count + ' murid dimuatkan · ' + (d.pp_meta.fileName || '') + ' · ' + new Date(d.pp_meta.importedAt).toLocaleString('ms-MY'), true);
    const h = document.createElement('tr');
    ['No. KP', 'Nama', 'Kelab & Persatuan', 'Badan Beruniform', 'Sukan & Permainan', 'Ekstra (Perkhidmatan)'].forEach((x) => { const th = document.createElement('th'); th.textContent = x; h.appendChild(th); });
    t.appendChild(h);
    ics.slice(0, 500).forEach((ic) => {
      const st = s[ic];
      const tr = document.createElement('tr');
      const cells = [ic, st.nama || ''].concat(PP.KOMPONEN_KEYS.map((k) => {
        const c = st.komponen[k] || {};
        const extra = PP.FIELDS.filter((f) => f !== 'aktiviti').filter((f) => c[f]).map((f) => PP.FIELD_LABEL[f] + ': ' + c[f]);
        return (c.aktiviti || '—') + (extra.length ? '\n' + extra.join(' · ') : '');
      }));
      cells.forEach((v) => { const td = document.createElement('td'); td.textContent = v; td.style.whiteSpace = 'pre-line'; tr.appendChild(td); });
      t.appendChild(tr);
    });
  }

  // ------------------------------------------------------------------
  // Nilai lalai
  // ------------------------------------------------------------------
  let defaults = JSON.parse(JSON.stringify(PP.DEFAULTS_TEMPLATE));
  let currentKomp = 'KELAB';
  let captured = {};

  function opt(sel, value, label, cur) {
    const o = document.createElement('option'); o.value = value; o.textContent = label; if (String(cur) === String(value)) o.selected = true; sel.appendChild(o); return o;
  }

  function splitPair(v) {
    const p = PP.splitList(v)[0] || '';
    const pe = PP.peringkatOf(p) || '';
    const rest = PP.norm(p).replace(/^[^:=]*[:=]?/, '').trim();
    return [pe, rest];
  }

  function renderDefTabs() {
    const box = $('defTabs'); box.innerHTML = '';
    PP.KOMPONEN_KEYS.forEach((k) => {
      const b = document.createElement('button');
      b.className = 'tab' + (k === currentKomp ? ' on' : '');
      b.textContent = PP.KOMPONEN[k].label;
      b.onclick = () => { readDefForm(); currentKomp = k; renderDefTabs(); renderDefForm(); };
      box.appendChild(b);
    });
  }

  function renderEkstraForm() {
    const d = defaults.EKSTRA || {};
    const f = $('defForm'); f.innerHTML = '';
    const note = document.createElement('p'); note.className = 'muted';
    note.innerHTML = '<b>Perkhidmatan</b> setiap murid diambil daripada lajur <i>Jawatan Khas</i> dalam fail — padankan nama jawatan dengan kategori SPPB di <b>bahagian 3</b> di bawah. Nilai di sini hanya untuk murid yang tiada nilai dalam fail. <b>— tidak diisi —</b> = jangan ubah apa yang ada dalam SPPB; <b>✕ Kosongkan</b> = buang pilihan sedia ada.';
    f.appendChild(note);
    const g = document.createElement('div'); g.className = 'grid'; f.appendChild(g);
    const row = (label, node) => { const l = document.createElement('label'); l.textContent = label; g.appendChild(l); g.appendChild(node); };

    // Perkhidmatan lalai
    const pkOpts = (captured.aktiviti && captured.aktiviti.EKSTRA) || PP.PERKHIDMATAN;
    const pk = document.createElement('select'); pk.id = 'e_pk'; pk.style.maxWidth = '640px';
    opt(pk, '', '— tidak diisi (jangan ubah) —', d.aktiviti || '');
    opt(pk, '__CLEAR__', '✕ Kosongkan (buang pilihan dalam SPPB)', d.aktiviti || '');
    pkOpts.forEach((x) => opt(pk, x, x, d.aktiviti || ''));
    if (d.aktiviti && d.aktiviti !== '__CLEAR__' && !pkOpts.includes(d.aktiviti)) opt(pk, d.aktiviti, d.aktiviti, d.aktiviti);
    const pkBox = document.createElement('div');
    const pkNote = document.createElement('div'); pkNote.className = 'muted'; pkNote.style.marginTop = '4px';
    pkNote.textContent = 'Hanya untuk murid yang TIADA Jawatan Khas dalam fail. Biarkan kosong jika murid biasa tidak diberi perkhidmatan.';
    pkBox.append(pk, pkNote);
    row('Perkhidmatan', pkBox);

    // Anugerah khas
    const a = PP.parseAnugerah(d.anugerah) || { label: '', tahap: null };
    const aBox = document.createElement('div'); aBox.className = 'inl';
    const aSel = document.createElement('select'); aSel.id = 'e_anu'; aSel.style.maxWidth = '520px';
    opt(aSel, '', '— tidak diisi (jangan ubah) —', a.label);
    opt(aSel, '__CLEAR__', '✕ Kosongkan (buang tanda dalam SPPB)', a.label);
    PP.ANUGERAH.forEach((x) => opt(aSel, x, x, a.label));
    const tSel = document.createElement('select'); tSel.id = 'e_anu_t';
    PP.ARP_TAHAP.forEach((x) => opt(tSel, x, x, a.tahap || 'EMAS'));
    const syncT = () => { tSel.style.display = aSel.value === PP.ANUGERAH[0] ? '' : 'none'; };
    aSel.onchange = syncT; syncT();
    aBox.append(aSel, tSel);
    row('Anugerah khas (maks. 1)', aBox);

    // Khidmat masyarakat
    const km = {};
    PP.parseKhidmatMasyarakat(d.khidmatMasyarakat).forEach((x) => {
      const i = PP.KHIDMAT_MASYARAKAT.findIndex((k) => PP.similarity(x.label, k, true) >= 0.6);
      if (i >= 0) km[i] = x.n;
    });
    const kmBox = document.createElement('div'); kmBox.id = 'e_km';
    PP.KHIDMAT_MASYARAKAT.forEach((k, i) => {
      const r = document.createElement('div'); r.className = 'inl'; r.style.margin = '2px 0';
      const sel = document.createElement('select'); sel.dataset.i = i;
      for (let n = 0; n <= 5; n++) opt(sel, String(n), n === 0 ? '0' : n + ' aktiviti', String(km[i] || 0));
      sel.onchange = () => {
        const tot = Array.from(kmBox.querySelectorAll('select')).reduce((s, x) => s + parseInt(x.value, 10), 0);
        if (tot > 5) { alert('Maksimum 5 aktiviti khidmat masyarakat (jumlah semua baris).'); sel.value = '0'; }
      };
      const lab = document.createElement('span'); lab.textContent = k.replace(/^AKTIVITI /, '');
      r.append(sel, lab); kmBox.appendChild(r);
    });
    const kmClear = document.createElement('label'); kmClear.className = 'chk';
    const kmc = document.createElement('input'); kmc.type = 'checkbox'; kmc.id = 'e_km_clear'; kmc.checked = d.khidmatMasyarakat === '__CLEAR__';
    const syncKm = () => kmBox.querySelectorAll('select').forEach((x) => { x.disabled = kmc.checked; });
    kmc.onchange = syncKm;
    kmClear.append(kmc, document.createTextNode('✕ Kosongkan semua tanda Khidmat Masyarakat dalam SPPB'));
    kmBox.appendChild(kmClear); syncKm();
    row('Khidmat masyarakat (jumlah maks. 5)', kmBox);

    // NILAM
    const nSel = document.createElement('select'); nSel.id = 'e_nilam';
    const nCur = d.nilam === '__CLEAR__' ? '__CLEAR__' : String(PP.parseNilam(d.nilam) || '');
    opt(nSel, '', '— tidak diisi (jangan ubah) —', nCur);
    opt(nSel, '__CLEAR__', '✕ Kosongkan (buang tanda dalam SPPB)', nCur);
    for (let n = 5; n >= 1; n--) opt(nSel, String(n), n + ' BINTANG', nCur);
    row('Program NILAM', nSel);

    // TIMSS & PISA
    const tOpts = (captured.timss && captured.timss.EKSTRA) || PP.TIMSS_PISA;
    const tm = document.createElement('select'); tm.id = 'e_timss'; tm.style.maxWidth = '640px';
    opt(tm, '', '— tidak diisi (jangan ubah) —', d.timss || '');
    opt(tm, '__CLEAR__', '✕ Kosongkan (buang pilihan dalam SPPB)', d.timss || '');
    tOpts.forEach((x) => opt(tm, x, x, d.timss || ''));
    if (d.timss && d.timss !== '__CLEAR__' && !tOpts.includes(d.timss)) opt(tm, d.timss, d.timss, d.timss);
    row('TIMSS dan PISA', tm);
  }

  function readEkstraForm() {
    if (!$('e_anu')) return;
    const an = $('e_anu').value;
    defaults.EKSTRA = {
      aktiviti: $('e_pk').value,
      anugerah: an === '__CLEAR__' ? '__CLEAR__' : an ? an + (an === PP.ANUGERAH[0] ? ':' + $('e_anu_t').value : '') : '',
      khidmatMasyarakat: $('e_km_clear').checked ? '__CLEAR__' : Array.from($('e_km').querySelectorAll('select')).filter((x) => x.value !== '0')
        .map((x) => PP.KHIDMAT_MASYARAKAT[+x.dataset.i] + ':' + x.value).join('; '),
      nilam: $('e_nilam').value,
      timss: $('e_timss').value.trim()
    };
  }

  function renderDefForm() {
    if (currentKomp === 'EKSTRA') return renderEkstraForm();
    const d = defaults[currentKomp] || {};
    const f = $('defForm'); f.innerHTML = '';
    const g = document.createElement('div'); g.className = 'grid'; f.appendChild(g);
    const row = (label, node) => { const l = document.createElement('label'); l.textContent = label; g.appendChild(l); g.appendChild(node); };

    // Jawatan
    const capJ = (captured.jawatan && captured.jawatan[currentKomp]) || [];
    const jList = Array.from(new Set([...PP.JAWATAN_UMUM, ...capJ]));
    const jParts = String(d.jawatan || '').split(';').map((x) => x.trim()).filter(Boolean);
    const cur = jParts[0] || '';
    const inList = !cur || jList.some((x) => PP.norm(x) === PP.norm(cur));
    const js = document.createElement('select'); js.id = 'd_jawatan_sel'; js.style.maxWidth = '420px';
    opt(js, '', '— tidak diisi —', inList ? cur : '__other');
    jList.forEach((x) => opt(js, x, x, inList ? (jList.find((y) => PP.norm(y) === PP.norm(cur)) || '') : '__other'));
    opt(js, '__other', '✎ Lain-lain (taip sendiri)…', inList ? '' : '__other');
    const jw = document.createElement('input'); jw.type = 'text'; jw.id = 'd_jawatan'; jw.value = inList ? '' : cur; jw.placeholder = 'taip nama jawatan';
    const syncJ = () => { jw.style.display = js.value === '__other' ? '' : 'none'; };
    js.onchange = syncJ; syncJ();
    const jwBox = document.createElement('div');
    const jwRow = document.createElement('div'); jwRow.className = 'inl'; jwRow.append(js, jw);
    jwBox.appendChild(jwRow);
    const fb = document.createElement('div'); fb.className = 'inl'; fb.style.marginTop = '6px';
    const fbl = document.createElement('span'); fbl.className = 'muted'; fbl.textContent = 'Jika tiada dalam senarai aktiviti itu, guna:';
    const fs = document.createElement('select'); fs.id = 'd_jawatan_fb';
    opt(fs, '', '— tiada sandaran —', jParts[1] || '');
    jList.forEach((x) => opt(fs, x, x, jParts[1] ? (jList.find((y) => PP.norm(y) === PP.norm(jParts[1])) || '') : ''));
    fb.append(fbl, fs);
    jwBox.appendChild(fb);
    const jn = document.createElement('div'); jn.className = 'muted'; jn.style.marginTop = '4px';
    jn.textContent = capJ.length ? 'Senarai termasuk ' + capJ.length + ' jawatan yang direkod daripada SPPB.'
      : 'Jawatan khusus (cth. LANS KOPERAL, BRASS BAND) akan ditambah ke senarai ini selepas extension membuka dropdown Jawatan dalam SPPB sekali.';
    jwBox.appendChild(jn);
    row('Jawatan', jwBox);

    // Pelibatan
    const [pp, pn] = splitPair(d.pelibatan);
    const pelBox = document.createElement('div'); pelBox.className = 'inl';
    const pSel = document.createElement('select'); pSel.id = 'd_pel_p'; opt(pSel, '', '— tidak diisi —', pp);
    PP.PERINGKAT.forEach((x) => opt(pSel, x.label, x.label, pp));
    const nSel = document.createElement('select'); nSel.id = 'd_pel_n';
    [1, 2, 3].forEach((n) => opt(nSel, n, 'Pelibatan ' + n, pn || 1));
    pelBox.append(pSel, nSel);
    row('Pelibatan', pelBox);

    // Pencapaian
    const [cp, cn] = splitPair(d.pencapaian);
    const capBox = document.createElement('div'); capBox.className = 'inl';
    const cSel = document.createElement('select'); cSel.id = 'd_cap_p'; opt(cSel, '', '— tidak diisi —', cp);
    PP.PERINGKAT.forEach((x) => opt(cSel, x.label, x.label, cp));
    const kSel = document.createElement('select'); kSel.id = 'd_cap_k';
    PP.KEDUDUKAN.forEach((x) => opt(kSel, x, x, cn || 'JOHAN'));
    capBox.append(cSel, kSel);
    row('Pencapaian', capBox);

    // Komitmen
    const chosen = PP.splitList(d.komitmen).map((x) => /^\d+$/.test(x) ? parseInt(x, 10) : KOMITMEN.findIndex((k) => k.includes(PP.norm(x))) + 1);
    const kb = document.createElement('div'); kb.className = 'komit'; kb.id = 'd_komit';
    KOMITMEN.forEach((k, i) => {
      const l = document.createElement('label'); l.className = 'chk';
      const c = document.createElement('input'); c.type = 'checkbox'; c.value = String(i + 1); c.checked = chosen.includes(i + 1);
      c.onchange = () => { const on = kb.querySelectorAll('input:checked'); if (on.length > 4) { c.checked = false; alert('Maksimum 4 pilihan komitmen.'); } };
      l.append(c, document.createTextNode((i + 1) + '. ' + k)); kb.appendChild(l);
    });
    row('Komitmen (maks. 4)', kb);

    // Khidmat
    const kh = document.createElement('select'); kh.id = 'd_khidmat'; opt(kh, '', '— tidak diisi —', d.khidmat || '');
    KHIDMAT.forEach((x, i) => opt(kh, String(i + 1), (i + 1) + '. ' + x, d.khidmat || ''));
    row('Khidmat sumbangan', kh);

    // Kehadiran
    const hd = document.createElement('select'); hd.id = 'd_kehadiran'; opt(hd, '', '— tidak diisi —', d.kehadiran === undefined ? '' : d.kehadiran);
    for (let i = 12; i >= 0; i--) opt(hd, String(i), String(i), d.kehadiran === undefined ? '' : d.kehadiran);
    row('Kehadiran', hd);

    const copy = document.createElement('button'); copy.className = 'btn'; copy.textContent = 'Salin nilai ini ke semua komponen';
    copy.onclick = () => { readDefForm(); PP.MAIN_KEYS.forEach((k) => { if (k !== currentKomp) defaults[k] = Object.assign({}, defaults[currentKomp]); }); status('defStatus', 'Disalin — tekan Simpan.', true); };
    row('', copy);
  }

  function readDefForm() {
    if (currentKomp === 'EKSTRA') return readEkstraForm();
    if (!$('d_jawatan_sel')) return;
    const p = $('d_pel_p').value, c = $('d_cap_p').value;
    defaults[currentKomp] = {
      jawatan: [($('d_jawatan_sel').value === '__other' ? $('d_jawatan').value.trim() : $('d_jawatan_sel').value), $('d_jawatan_fb').value]
        .filter(Boolean).filter((x, i, a) => a.indexOf(x) === i).join('; '),
      pelibatan: p ? p + ':' + $('d_pel_n').value : '',
      pencapaian: c ? c + ':' + $('d_cap_k').value : '',
      komitmen: Array.from($('d_komit').querySelectorAll('input:checked')).map((x) => x.value).join(';'),
      khidmat: $('d_khidmat').value,
      kehadiran: $('d_kehadiran').value
    };
  }

  $('btnSaveDef').onclick = async () => { readDefForm(); await store.set({ pp_defaults: defaults }); status('defStatus', '✓ Disimpan', true); };

  // ------------------------------------------------------------------
  // Padanan
  // ------------------------------------------------------------------
  async function renderMatches() {
    const d = await store.get(['pp_students', 'pp_options', 'pp_mapping']);
    captured = d.pp_options || {};
    const mapping = PP.parseMapping(d.pp_mapping || '');
    const s = d.pp_students || {};
    const box = $('matchTable'); box.innerHTML = '';
    const uniq = {};
    Object.values(s).forEach((st) => PP.KOMPONEN_KEYS.forEach((k) => {
      const a = PP.effectiveFor(st, null, k).aktiviti;
      if (a) { uniq[k] = uniq[k] || {}; uniq[k][PP.norm(a)] = (uniq[k][PP.norm(a)] || 0) + 1; }
    }));
    if (!Object.keys(uniq).length) { box.innerHTML = '<p class="muted">Import data dahulu untuk melihat padanan.</p>'; return; }
    let unmapped = 0;
    const t = document.createElement('table'); t.className = 'match';
    t.innerHTML = '<tr><th>Komponen</th><th>Nama dalam fail</th><th>Murid</th><th>Pilihan SPPB</th><th>Status</th></tr>';
    PP.KOMPONEN_KEYS.forEach((k) => {
      const opts = (captured.aktiviti && captured.aktiviti[k]) || (k === 'EKSTRA' ? PP.PERKHIDMATAN : []);
      Object.keys(uniq[k] || {}).sort().forEach((name) => {
        const tr = document.createElement('tr');
        const m = opts.length ? PP.matchFor(k, 'aktiviti', name, opts, mapping) : null;
        const td = (x) => { const e = document.createElement('td'); if (x != null) e.append(x); tr.appendChild(e); return e; };
        td(PP.KOMPONEN[k].label); td(name); td(String(uniq[k][name]));
        const badge = document.createElement('span');
        if (!opts.length) {
          td('—'); badge.className = 'badge b-warn'; badge.textContent = 'Senarai SPPB belum direkod';
        } else {
          const sel = document.createElement('select');
          sel.dataset.src = name;
          opt(sel, '', '— pilih —', '');
          opts.forEach((o) => opt(sel, o, o, m && m.option ? m.option : ''));
          sel.onchange = () => { badge.className = 'badge b-ok'; badge.textContent = 'Manual (tekan Simpan peta)'; };
          td(sel);
          if (m && m.option) { const strong = m.reason === 'tepat' || m.score >= 0.9; badge.className = 'badge ' + (strong ? 'b-ok' : 'b-warn'); badge.textContent = m.reason === 'tepat' ? 'Tepat' : m.reason === 'peta manual' ? 'Peta manual' : strong ? 'Padan' : 'Anggaran — sahkan'; }
          else { badge.className = 'badge b-err'; badge.textContent = '⚠ Perlu dipetakan' + (m && m.reason ? ' (' + m.reason.replace(/ — perlu dipetakan$/, '') + ')' : ''); unmapped++; }
        }
        td(badge);
        t.appendChild(tr);
      });
    });
    if (unmapped) {
      const w = document.createElement('div'); w.className = 'status err'; w.style.margin = '0 0 8px';
      w.textContent = '⚠ ' + unmapped + ' nama belum dapat dipadankan dengan pasti. Pilih kategori yang betul dalam dropdown, kemudian tekan "➕ Tambah pilihan di atas ke peta manual" dan "Simpan peta". Murid berkenaan tidak akan diisi (atau isi pukal dijeda) sehingga dipetakan.';
      box.appendChild(w);
    }
    box.appendChild(t);
    const b = document.createElement('div'); b.className = 'row';
    const btn = document.createElement('button'); btn.className = 'btn'; btn.textContent = '➕ Tambah pilihan di atas ke peta manual';
    btn.onclick = () => {
      const cur = PP.parseMapping($('mapping').value);
      const lines = $('mapping').value.split(/\r?\n/).filter((l) => l.trim());
      t.querySelectorAll('select').forEach((sel) => {
        if (!sel.value) return;
        const k = PP.norm(sel.dataset.src);
        if (PP.norm(sel.value) === k) return;
        if (cur[k]) { const i = lines.findIndex((l) => PP.norm(l.split(/=>|=/)[0]) === k); if (i >= 0) lines.splice(i, 1); }
        lines.push(sel.dataset.src + ' = ' + sel.value);
      });
      $('mapping').value = lines.join('\n');
      status('mapStatus', 'Ditambah — tekan Simpan peta.', true);
    };
    b.appendChild(btn); box.appendChild(b);
  }

  $('btnSaveMap').onclick = async () => { await store.set({ pp_mapping: $('mapping').value }); status('mapStatus', '✓ Disimpan', true); renderMatches(); };

  // ------------------------------------------------------------------
  // Tetapan
  // ------------------------------------------------------------------
  async function loadSettings() {
    const d = await store.get(['pp_settings', 'pp_defaults', 'pp_mapping']);
    const s = Object.assign({}, PP.DEFAULT_SETTINGS, d.pp_settings || {});
    $('setOverwrite').checked = !!s.overwrite;
    $('setStop').checked = !!s.stopOnError;
    if (!Array.from($('setDelay').options).some((o) => o.value === String(s.stepDelay))) { const o = document.createElement('option'); o.value = String(s.stepDelay); o.textContent = s.stepDelay; $('setDelay').appendChild(o); }
    $('setDelay').value = String(s.stepDelay);
    defaults = Object.assign(JSON.parse(JSON.stringify(PP.DEFAULTS_TEMPLATE)), d.pp_defaults || {});
    $('mapping').value = d.pp_mapping || '';
  }
  $('btnSaveSet').onclick = async () => {
    const d = await store.get(['pp_settings']);
    const s = Object.assign({}, PP.DEFAULT_SETTINGS, d.pp_settings || {}, {
      overwrite: $('setOverwrite').checked, stopOnError: $('setStop').checked, stepDelay: parseInt($('setDelay').value, 10)
    });
    await store.set({ pp_settings: s });
    status('setStatus', '✓ Disimpan', true);
  };

  // ------------------------------------------------------------------
  // Eksport / import tetapan
  // ------------------------------------------------------------------
  const SETTING_KEYS = ['pp_defaults', 'pp_mapping', 'pp_settings', 'pp_options'];
  const STUDENT_KEYS = ['pp_students', 'pp_meta'];

  $('btnExport').onclick = async () => {
    readDefForm();
    const withStudents = $('expStudents').checked;
    const d = await store.get(SETTING_KEYS.concat(withStudents ? STUDENT_KEYS : []));
    if (!d.pp_defaults) d.pp_defaults = defaults;
    const out = { app: 'pajsk-pembantu', version: chrome.runtime.getManifest().version, exportedAt: new Date().toISOString(), data: d };
    const a = document.createElement('a');
    a.href = URL.createObjectURL(new Blob([JSON.stringify(out, null, 2)], { type: 'application/json' }));
    a.download = 'pajsk-pembantu-tetapan-' + new Date().toISOString().slice(0, 10) + (withStudents ? '-dengan-murid' : '') + '.json';
    a.click();
    status('expStatus', '✓ Tetapan dieksport' + (withStudents ? ' (termasuk data murid)' : '') + '.', true);
  };

  $('impFile').addEventListener('change', async (ev) => {
    const f = ev.target.files[0];
    ev.target.value = '';
    if (!f) return;
    try {
      const j = JSON.parse(await f.text());
      if (!j || j.app !== 'pajsk-pembantu' || typeof j.data !== 'object') throw new Error('Bukan fail tetapan PAJSK Pembantu.');
      const allowed = SETTING_KEYS.concat(STUDENT_KEYS);
      const put = {};
      for (const k of allowed) if (j.data[k] !== undefined) put[k] = j.data[k];
      if (!Object.keys(put).length) throw new Error('Fail tidak mengandungi tetapan.');
      const hasStu = !!put.pp_students;
      const msg = 'Import tetapan dari "' + f.name + '" (v' + (j.version || '?') + ')?\n\n' +
        'Nilai lalai, peta padanan dan tetapan semasa akan DIGANTI.' + (hasStu ? '\nData murid semasa juga akan diganti (' + Object.keys(put.pp_students).length + ' murid).' : '');
      if (!confirm(msg)) return;
      await store.set(put);
      status('expStatus', '✓ Tetapan diimport. Halaman dimuat semula…', true);
      setTimeout(() => location.reload(), 700);
    } catch (e) {
      status('expStatus', '✖ ' + e.message, false);
    }
  });

  chrome.storage.onChanged.addListener((ch) => { if (ch.pp_options) { readDefForm(); renderMatches().then(renderDefForm); } });

  (async () => {
    await loadSettings();
    await renderMatches();
    renderDefTabs(); renderDefForm();
    await renderPreview();
  })();
})();
