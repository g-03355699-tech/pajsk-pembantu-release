# PAJSK Pembantu

Extension Google Chrome untuk membantu guru mengisi **PAJSK** dalam **SPPB** (moeissppb.moe.gov.my).

## Fungsi
1. **Isi markah automatik.** Import fail data murid (.xls / .xlsx / .csv, atau tampal terus dari Excel / Google Sheets). Murid dipadankan mengikut No. KP. Extension kemudian mengisi Aktiviti, Jawatan, Pelibatan, Pencapaian, Komitmen, Khidmat Sumbangan dan Kehadiran bagi tab Kelab & Persatuan, Badan Beruniform serta Sukan & Permainan.
2. **Ekstra Kurikulum.** Lajur *Jawatan Khas* (Pengawas, AJK Kelas, PRS, J/K Pusat Media dll.) diisi ke dropdown **Perkhidmatan** dalam tab Ekstra Kurikulum.
2. **Isi pukal satu kelas.** Dari halaman Senarai Murid, extension membuka setiap murid, mengisi borang, menekan Simpan dan beralih ke murid seterusnya. Proses berhenti sendiri jika berlaku ralat. Ada pilihan untuk berhenti pada setiap murid supaya guru boleh menyemak dahulu.
3. **Eksport data murid.** Senarai murid kelas (aktiviti, skor, tambahan, GPA, CGPA, gred dan status) dimuat turun sebagai CSV.
4. **Semak data tak lengkap.** Murid yang belum ditaksir, komponen yang belum diisi atau tiada skor, serta aktiviti SPPB yang berbeza daripada data import akan ditandakan.

## Pasang
1. Ekstrak fail ZIP ke satu folder tetap, contohnya `Documents\pajsk-pembantu`.
2. Buka `chrome://extensions`, kemudian hidupkan **Developer mode** (penjuru kanan atas).
3. Klik **Load unpacked** dan pilih folder tersebut.
4. Pin ikon PAJSK Pembantu pada bar Chrome.

## Cara guna
1. Klik ikon, pilih **Import data & tetapan**, dan pilih fail Excel (contohnya eksport *table2excel*).
2. Tetapkan **nilai lalai** bagi setiap komponen: Jawatan, Pelibatan, Komitmen (maksimum 4), Khidmat dan Kehadiran.
3. Dalam SPPB, buka **Keputusan → PAJSK → kelas**. Butang hijau **PAJSK** akan muncul di penjuru kanan bawah.
4. Untuk percubaan pertama, buka seorang murid dan tekan **Isi borang**. Semak hasilnya sebelum menekan Simpan.
5. Lepas itu, kembali ke Senarai Murid dan tekan **Mula isi pukal**.
6. Selepas isi borang dijalankan sekali, senarai pilihan aktiviti SPPB direkodkan. Halaman Tetapan bahagian 3 akan menunjukkan padanan nama (contohnya `KELAB KOPERASI` dipadankan dengan `KELAB KOPERASI SEKOLAH (SM)`). Betulkan mana-mana padanan yang salah dalam **Peta manual**.

## Format fail
Lajur wajib: `IC` / `No. KP` / `Id Pengenalan`. Lajur lain adalah pilihan; rujuk `templat_pajsk_pembantu.csv`.

| Medan | Contoh |
|---|---|
| Kelab/Persatuan, Badan Beruniform, Sukan/Permainan | `KELAB KOPERASI` |
| Jawatan Kelab / Uniform / Sukan | `AHLI AKTIF` |
| Pelibatan … | `SEKOLAH:3; ZON/DAERAH:1` |
| Pencapaian … | `ZON/DAERAH:JOHAN` |
| Komitmen … | `7;8;10;12` |
| Khidmat … | `1` – `4` |
| Kehadiran … | `0` – `12` |

Medan yang kosong akan menggunakan nilai lalai. Bagi murid yang ada dalam data tetapi tiada aktiviti untuk sesuatu komponen, suis **DITAKSIR** komponen itu akan dimatikan.

## Kemas kini
Extension menyemak versi baharu secara automatik (setiap 6 jam) daripada repo awam [pajsk-pembantu-release](https://github.com/g-03355699-tech/pajsk-pembantu-release). Apabila ada versi baharu, ikon menunjukkan lencana **NEW** dan notis kuning dipaparkan dalam popup serta panel PAJSK.
1. Klik **Muat turun versi baharu**.
2. Unzip dan **gantikan fail dalam folder yang sama** (data dan tetapan kekal).
3. `chrome://extensions` → tekan ↻ **Reload** pada PAJSK Pembantu.
4. Tekan F5 pada halaman SPPB.

## Privasi
Semua data disimpan setempat dalam Chrome (`chrome.storage.local`). Extension hanya berjalan di `moeissppb.moe.gov.my` dan tidak menghantar data ke pelayan lain.

## Changelog
- **1.4.0** (3 Nov 2026): Dropdown **Perkhidmatan** lalai dan senarai kategori Perkhidmatan SPPB dalam padanan; padanan pintar kategori bergaris miring (cth. Pengawas Biasa → PENGAWAS/…|7); dropdown **Jawatan** dalam nilai lalai (gabungan jawatan yang direkod daripada SPPB, cth. LANS KOPERAL untuk Badan Beruniform); dropdown **TIMSS dan PISA**.
- **1.3.0** (3 Nov 2026): Tab **Ekstra Kurikulum** lengkap — Anugerah Khas (termasuk Emas/Perak/Gangsa ARP), Khidmat Masyarakat, Program NILAM dan TIMSS/PISA; nilai lalai Ekstra dalam Tetapan; lajur baharu dalam fail/templat.
- **1.2.0** (3 Nov 2026): Sokongan tab **Ekstra Kurikulum** — lajur Jawatan Khas diisi ke dropdown Perkhidmatan; suis DITAKSIR Ekstra dimatikan bagi murid tanpa jawatan khas; semakan & eksport merangkumi Ekstra.
- **1.1.0** (3 Nov 2026): Semakan kemas kini automatik — lencana NEW pada ikon, notis versi baharu dalam popup dan panel, pautan "Semak kemas kini".
- **1.0.1** (3 Nov 2026): Popup memaklumkan jika halaman perlu dimuat semula (F5); contoh jawatan ditukar kepada AHLI AKTIF.
- **1.0.0** (3 Nov 2026): Keluaran pertama. Fungsi isi automatik, isi pukal, eksport CSV, semakan data, padanan nama dan peta manual.
