// PAJSK Pembantu — fungsi kongsi (content script + halaman tetapan)
(function (root) {
  'use strict';

  const KOMPONEN = {
    KELAB: { label: 'Kelab & Persatuan', tabKey: 'KELAB' },
    UNIFORM: { label: 'Badan Beruniform', tabKey: 'BERUNIFORM' },
    SUKAN: { label: 'Sukan & Permainan', tabKey: 'SUKAN' },
    EKSTRA: { label: 'Ekstra Kurikulum', tabKey: 'EKSTRA', ekstra: true }
  };
  const KOMPONEN_KEYS = Object.keys(KOMPONEN);
  // komponen yang ada Jawatan/Pelibatan/Komitmen dll. (Ekstra hanya ada Perkhidmatan)
  const MAIN_KEYS = ['KELAB', 'UNIFORM', 'SUKAN'];

  const FIELDS = ['aktiviti', 'jawatan', 'pelibatan', 'pencapaian', 'komitmen', 'khidmat', 'kehadiran',
    'anugerah', 'khidmatMasyarakat', 'nilam', 'timss'];
  const EKSTRA_FIELDS = ['anugerah', 'khidmatMasyarakat', 'nilam', 'timss'];
  // Medan yang datang daripada "Slip Infomurid Kelas" — bagi murid dari slip, slip adalah sumber sahih
  // (kosong dalam slip = kosong; nilai lalai tidak digunakan untuk medan ini)
  const SLIP_FIELDS = ['aktiviti', 'jawatan', 'pelibatan', 'pencapaian', 'kehadiran'];

  // Senarai seperti dalam tab Ekstra Kurikulum SPPB
  const ANUGERAH = [
    'ANUGERAH REMAJA PERDANA',
    'PROGRAM KEPIMPINAN GENERASI MADANI - TIER 3',
    'PROGRAM KEPIMPINAN GENERASI MADANI - TIER 2',
    'ANUGERAH PENGAKAP RAJA / RAMBU PENGAKAP KANAK-KANAK',
    'ANUGERAH PANDU PUTERI RAJA / PANDU PUTERI TUNAS KETUA PESURUHJAYA',
    'ANUGERAH PUTERI AZ-ZAHRA / PUTERI BONGSU - PPIM',
    'ANUGERAH GRAND PRIOR / PERISAI PERKHIDMATAN KHAS 1000 JAM EMAS - SJAM',
    'ANUGERAH KHAS KOKURIKULUM DAN SUKAN - KEBANGSAAN',
    'ANUGERAH KHAS KOKURIKULUM DAN SUKAN - NEGERI',
    'ANUGERAH KHAS KOKURIKULUM DAN SUKAN - ZON/DAERAH/BAHAGIAN',
    'ANUGERAH KHAS KOKURIKULUM DAN SUKAN - SEKOLAH',
    'ANUGERAH-ANUGERAH LAIN/PENGHARGAAN KHAS SETARA - KEBANGSAAN',
    'ANUGERAH-ANUGERAH LAIN/PENGHARGAAN KHAS SETARA - NEGERI',
    'ANUGERAH-ANUGERAH LAIN/PENGHARGAAN KHAS SETARA - ZON/DAERAH/BAHAGIAN'
  ];
  const ARP_TAHAP = ['EMAS', 'PERAK', 'GANGSA'];
  const TIMSS_PISA = [
    'PENYERTAAN PERINGKAT ANTARABANGSA MENCAPAI TAHAP CEMERLANG|10',
    'PENYERTAAN PERINGKAT ANTARABANGSA|8',
    'PENYERTAAN PERINGKAT KEBANGSAAN|6'
  ];
  // Jawatan umum yang ada dalam semua komponen (senarai penuh direkod daripada SPPB)
  const JAWATAN_UMUM = ['AHLI AKTIF', 'AHLI BIASA', 'AHLI JAWATANKUASA'];
  // Pilihan dropdown Perkhidmatan dalam SPPB (digantikan dengan senarai sebenar apabila extension membuka dropdown)
  const PERKHIDMATAN = [
    'KETUA MURID/PENGERUSI|10',
    'TIMBALAN/PENOLONG KETUA MURID|8',
    'PENGAWAS/PENGAWAS PUSAT SUMBER/KETUA ASRAMA/KETUA PRS/KETUA BADAR/KUARTERMASTER/PENGERUSI BADAN PERKHIDMATAN SEKOLAH|7',
    'PENOLONG KETUA ASRAMA/PENOLONG KETUA BADAR/AHLI LEMBAGA PENGARAH KOPERASI SEKOLAH|6',
    'AJK UTAMA BADAN-BADAN PERKHIDMATAN ATAU PENGURUSAN/BENDAHARI/SETIAUSAHA/KETUA BIRO-ASRAMA/PRS/PENERIMA SIJIL DAN LENCANA SLAD/PROSTAR/PENGAWAS KOPERASI/KETUA KELAS/KETUA TINGKATAN|5',
    'AJK KECIL BIRO/KETUA BILIK/KETUA DORM/AJK BADAR/PENERIMA SIJIL SLAD/PENOLONG KETUA KELAS/PENOLONG KETUA BILIK|3',
    'PENGAWAS PUSAT SUMBER (TINGKATAN 6)|6'
  ];
  const KHIDMAT_MASYARAKAT = ['AKTIVITI KEJIRANAN/KOMUNITI', 'AKTIVITI ALAM SEKITAR', 'AKTIVITI BENCANA ALAM', 'AKTIVITI KEROHANIAN',
    'AKTIVITI KHIDMAT JABATAN/AGENSI', 'AKTIVITI KEBUDAYAAN/KESENIAN/INTEGRASI', 'AKTIVITI INSANIAH'];
  const FIELD_LABEL = {
    aktiviti: 'Aktiviti',
    jawatan: 'Jawatan',
    pelibatan: 'Pelibatan',
    pencapaian: 'Pencapaian',
    komitmen: 'Komitmen',
    khidmat: 'Khidmat Sumbangan',
    kehadiran: 'Kehadiran',
    anugerah: 'Anugerah Khas',
    khidmatMasyarakat: 'Khidmat Masyarakat',
    nilam: 'Program NILAM',
    timss: 'TIMSS dan PISA'
  };

  // Label peringkat seperti dalam borang SPPB + alias yang diterima
  const PERINGKAT = [
    { label: 'ANTARABANGSA', alias: ['ANTARABANGSA', 'INTERNATIONAL'] },
    { label: 'KEBANGSAAN', alias: ['KEBANGSAAN', 'NASIONAL', 'NATIONAL'] },
    { label: 'NEGERI', alias: ['NEGERI', 'STATE'] },
    { label: 'BAHAGIAN (SABAH/SARAWAK)', alias: ['BAHAGIAN'] },
    { label: 'ZON/DAERAH', alias: ['ZON/DAERAH', 'ZON', 'DAERAH', 'ZONE'] },
    { label: 'SEKOLAH', alias: ['SEKOLAH', 'SCHOOL'] }
  ];
  const KEDUDUKAN = ['JOHAN', 'NAIB JOHAN', 'KETIGA', 'KEEMPAT', 'KELIMA'];
  const KEDUDUKAN_ALIAS = {
    '1': 'JOHAN', 'JOHAN': 'JOHAN', 'PERTAMA': 'JOHAN',
    '2': 'NAIB JOHAN', 'NAIB JOHAN': 'NAIB JOHAN', 'NAIB': 'NAIB JOHAN', 'KEDUA': 'NAIB JOHAN',
    '3': 'KETIGA', 'KETIGA': 'KETIGA', 'TEMPAT KETIGA': 'KETIGA',
    '4': 'KEEMPAT', 'KEEMPAT': 'KEEMPAT',
    '5': 'KELIMA', 'KELIMA': 'KELIMA'
  };

  function norm(s) {
    return String(s == null ? '' : s)
      .replace(/[‘’‛`´]/g, "'")
      .replace(/\s+/g, ' ')
      .trim()
      .toUpperCase();
  }

  function normIC(s) {
    return String(s == null ? '' : s).replace(/\D/g, '');
  }

  // ---------- Padanan nama aktiviti / jawatan ----------
  const STOP = new Set(['KELAB', 'PERSATUAN', 'PASUKAN', 'SEKOLAH', 'DAN', 'SM', 'SR', 'THE', 'OF', 'UNIT', 'BADAN']);
  const EXPAND = { BI: ['BAHASA', 'INGGERIS'], BM: ['BAHASA', 'MELAYU'], BA: ['BAHASA', 'ARAB'], BC: ['BAHASA', 'CINA'],
    PRS: ['PEMBIMBING', 'RAKAN', 'SEBAYA'], JK: ['AJK'], JAWATANKUASA: ['AJK'] };

  function tokens(s, keepStop) {
    const t = norm(s).replace(/\bJ\s*\/\s*K\b/g, ' AJK ').replace(/&/g, ' DAN ').replace(/[^A-Z0-9' ]+/g, ' ').replace(/'/g, '').split(' ').filter(Boolean);
    const out = [];
    for (const w of t) {
      if (EXPAND[w]) out.push(...EXPAND[w]);
      else out.push(w);
    }
    const f = keepStop ? out : out.filter((w) => !STOP.has(w));
    return f.length ? f : out;
  }

  function lev(a, b) {
    const m = a.length, n = b.length;
    let prev = Array.from({ length: n + 1 }, (_, j) => j);
    for (let i = 1; i <= m; i++) {
      const cur = [i];
      for (let j = 1; j <= n; j++) cur[j] = Math.min(prev[j] + 1, cur[j - 1] + 1, prev[j - 1] + (a[i - 1] === b[j - 1] ? 0 : 1));
      prev = cur;
    }
    return prev[n];
  }

  function similarity(a, b, keepStop) {
    const na = norm(a), nb = norm(b);
    if (!na || !nb) return 0;
    if (na === nb) return 1;
    const A = new Set(tokens(a, keepStop)), B = new Set(tokens(b, keepStop));
    if (!A.size || !B.size) return 0;
    // setiap perkataan B hanya boleh dipadankan SEKALI (padanan tepat dahulu, kemudian toleransi ejaan)
    let inter = 0;
    const used = new Set();
    const rest = [];
    for (const x of A) { if (B.has(x) && !used.has(x)) { used.add(x); inter++; } else rest.push(x); }
    for (const x of rest) {
      // toleransi ejaan (cth. TAEKWANDO / TAEKWONDO, RAGBI / RUGBI)
      const tol = x.length >= 8 ? 2 : x.length >= 5 ? 1 : 0;
      if (!tol) continue;
      const y = Array.from(B).find((y) => !used.has(y) && Math.abs(y.length - x.length) <= tol && lev(x, y) <= tol);
      if (y) { used.add(y); inter++; }
    }
    if (!inter) return 0;
    const dice = (2 * inter) / (A.size + B.size);
    if (A.size === B.size && inter === A.size) return 0.98;
    const contained = inter === Math.min(A.size, B.size);
    return contained ? Math.max(dice, 0.75) : dice;
  }

  // Peta manual: "NAMA DALAM FAIL = NAMA DALAM SPPB" (satu baris setiap padanan)
  function parseMapping(text) {
    const map = {};
    String(text || '').split(/\r?\n/).forEach((line) => {
      const m = line.split(/=>|=|\t/);
      if (m.length >= 2) {
        const k = norm(m[0]); const v = m.slice(1).join('=').trim();
        if (k && v) map[k] = v;
      }
    });
    return map;
  }

  // Pulangkan { option, score, reason } ; option = null jika tiada padanan selamat
  // Pilihan berkategori seperti "PENGAWAS/PENGAWAS PUSAT SUMBER/KETUA PRS|7":
  // buang "|7" dan bandingkan juga dengan setiap bahagian yang dipisahkan "/".
  function optionScore(target, o, keepStop) {
    const m = String(o).match(/^(.*?)\s*\|\s*\d+\s*$/);
    if (!m) return similarity(target, o, keepStop);
    const base = m[1];
    let best = similarity(target, base, keepStop);
    for (const seg of base.split('/')) {
      if (!seg.trim()) continue;
      const s = similarity(target, seg, keepStop);
      if (s > best) best = s;
    }
    return best;
  }

  // Padanan TEGAS untuk Perkhidmatan (Jawatan Khas): hanya terima jika nama jawatan sama
  // dengan salah satu bahagian "/" dalam tepat SATU kategori. Jika tidak pasti → perlu peta manual.
  const PK_FILLER = new Set(['BIASA']);
  function pkTokens(s) { return tokens(s).filter((t) => !PK_FILLER.has(t)).sort().join(' '); }
  function pkSegMatch(wt, seg) {
    const a = pkTokens(seg);
    if (a === wt) return true;
    const A = a.split(' '), W = wt.split(' ');
    if (A.length !== W.length) return false;
    return A.every((x, i) => x === W[i] || (x.length >= 6 && lev(x, W[i]) <= 1));
  }
  function scoreOf(o) { const m = String(o).match(/\|\s*(\d+)\s*$/); return m ? parseInt(m[1], 10) : null; }
  function matchPerkhidmatan(wanted, options, mapping, score) {
    const w = norm(wanted);
    if (!w) return { option: null, score: 0, reason: 'kosong' };
    if (mapping && mapping[w]) {
      const t = norm(mapping[w]);
      const o = options.find((x) => norm(x) === t) || options.find((x) => norm(x).startsWith(t));
      return o ? { option: o, score: 1, reason: 'peta manual' } : { option: null, score: 0, reason: 'peta manual "' + mapping[w] + '" tiada dalam senarai SPPB' };
    }
    const exact = options.find((o) => norm(o) === w || norm(o).replace(/\s*\|\s*\d+\s*$/, '') === w);
    if (exact) return { option: exact, score: 1, reason: 'tepat' };
    const wt = pkTokens(wanted);
    const hits = options.filter((o) => {
      const base = String(o).replace(/\s*\|\s*\d+\s*$/, '');
      return base.split('/').some((seg) => seg.trim() && pkSegMatch(wt, seg));
    });
    if (hits.length === 1) return { option: hits[0], score: 1, reason: 'tepat' };
    // Tiada padanan nama: guna skor daripada slip (kategori SPPB ditanda "|skor")
    if (score != null && score !== '' && !isNaN(score)) {
      let byScore = options.filter((o) => scoreOf(o) === Number(score));
      if (byScore.length > 1) byScore = byScore.filter((o) => !/TINGKATAN\s*6/i.test(o));
      if (byScore.length === 1) return { option: byScore[0], score: 0.9, reason: 'ikut skor ' + score };
    }
    const near = options.map((o) => ({ o, s: optionScore(wanted, o) })).sort((a, b) => b.s - a.s).filter((x) => x.s > 0).slice(0, 3).map((x) => x.o);
    return { option: null, score: 0, reason: hits.length > 1 ? 'tidak pasti (lebih dari satu kategori)' : 'tidak pasti — perlu dipetakan', candidates: near };
  }

  function matchFor(komp, kind, wanted, options, mapping, keepStop, score) {
    if (komp === 'EKSTRA' && kind === 'aktiviti') return matchPerkhidmatan(wanted, options, mapping, score);
    return bestMatch(wanted, options, mapping, keepStop);
  }

  function bestMatch(wanted, options, mapping, keepStop) {
    const w = norm(wanted);
    if (!w) return { option: null, score: 0, reason: 'kosong' };
    let target = wanted;
    if (mapping && mapping[w]) target = mapping[w];
    const nt = norm(target);
    const exact = options.find((o) => norm(o) === nt);
    if (exact) return { option: exact, score: 1, reason: 'tepat' };
    const scored = options.map((o) => ({ o, s: optionScore(target, o, keepStop) })).sort((x, y) => y.s - x.s);
    if (!scored.length || scored[0].s < 0.6) {
      return { option: null, score: scored.length ? scored[0].s : 0, reason: 'tiada padanan', candidates: scored.slice(0, 3).map((x) => x.o) };
    }
    if (scored[1] && scored[0].s - scored[1].s < 0.08) {
      return { option: null, score: scored[0].s, reason: 'samar (lebih dari satu calon)', candidates: scored.slice(0, 3).map((x) => x.o) };
    }
    return { option: scored[0].o, score: scored[0].s, reason: 'anggaran' };
  }

  // ---------- Penghurai nilai medan ----------
  function splitList(v) {
    return String(v == null ? '' : v).split(/[;,\n|]+/).map((x) => x.trim()).filter(Boolean);
  }

  function peringkatOf(s) {
    const n = norm(s);
    for (const p of PERINGKAT) {
      if (p.alias.some((a) => n === a || n.startsWith(a + ' ') || n.startsWith(a + ':') || n.startsWith(a + '='))) return p.label;
    }
    for (const p of PERINGKAT) if (p.alias.some((a) => n.includes(a))) return p.label;
    return null;
  }

  // "SEKOLAH:3; ZON/DAERAH:1"  atau "SEKOLAH" (=1)
  function parsePelibatan(v) {
    const out = [];
    for (const part of splitList(v)) {
      const p = peringkatOf(part);
      if (!p) continue;
      const m = norm(part).match(/(\d+)\s*$/);
      let n = m ? parseInt(m[1], 10) : 1;
      if (n < 1) n = 1; if (n > 3) n = 3;
      out.push({ peringkat: p, col: n });
    }
    return out;
  }

  // "ZON/DAERAH:JOHAN"  atau "DAERAH:1"
  function parsePencapaian(v) {
    const out = [];
    for (const part of splitList(v)) {
      const p = peringkatOf(part);
      if (!p) continue;
      const rest = norm(part).replace(/^[^:=]*[:=]/, '').trim();
      let k = KEDUDUKAN_ALIAS[rest];
      if (!k) for (const key of Object.keys(KEDUDUKAN_ALIAS)) if (isNaN(key) && rest.includes(key)) { k = KEDUDUKAN_ALIAS[key]; }
      if (!k) continue;
      out.push({ peringkat: p, col: k });
    }
    return out;
  }

  function parseKehadiran(v) {
    const s = String(v == null ? '' : v).trim();
    if (s === '') return null;
    const n = parseInt(s, 10);
    if (isNaN(n) || n < 0) return null;
    return Math.min(n, 12);
  }

  // "ANUGERAH REMAJA PERDANA:EMAS" / "PROGRAM KEPIMPINAN GENERASI MADANI - TIER 3"
  function parseAnugerah(v) {
    const s = splitList(v)[0];
    if (!s) return null;
    const m = norm(s).match(/^(.*?)\s*[:=]\s*(EMAS|PERAK|GANGSA)\s*$/) || norm(s).match(/^(.*?)\s+(EMAS|PERAK|GANGSA)\s*$/);
    return m ? { label: m[1].trim(), tahap: m[2] } : { label: norm(s), tahap: null };
  }
  // "KEJIRANAN:2; ALAM SEKITAR:1"  (nombor = bilangan aktiviti, jumlah maks. 5)
  function parseKhidmatMasyarakat(v) {
    const out = [];
    for (const part of splitList(v)) {
      const m = norm(part).match(/^(.*?)\s*[:=]?\s*(\d+)\s*$/);
      const label = (m ? m[1] : norm(part)).trim();
      let n = m ? parseInt(m[2], 10) : 1;
      if (!label || n < 1) continue;
      out.push({ label, n: Math.min(n, 5) });
    }
    return out;
  }
  function parseNilam(v) {
    const m = String(v == null ? '' : v).match(/[1-5]/);
    return m ? parseInt(m[0], 10) : null;
  }

  function isBlank(v) {
    return v == null || String(v).trim() === '' || String(v).trim() === '-';
  }

  // ---------- Import jadual (array baris) ----------
  function classifyHeader(h) {
    const n = norm(h).replace(/\s*\/\s*/g, '/');
    if (!n) return null;
    if (/^(BIL|BILL|NO|NO\.)$/.test(n)) return null;
    if (n === 'IC' || n.includes('PENGENALAN') || /\bNO\.? ?KP\b/.test(n) || n === 'KP' || n.includes('MYKID') || n.includes('MYKAD') || n === 'NO IC' || n === 'NO. IC')
      return { f: 'ic' };
    if (n.startsWith('NAMA')) return { f: 'nama' };
    if (n === 'KELAS') return { f: 'kelas' };
    if (n.includes('ANUGERAH')) return { f: 'anugerah', komp: 'EKSTRA' };
    if (n.includes('KHIDMAT MASYARAKAT')) return { f: 'khidmatMasyarakat', komp: 'EKSTRA' };
    if (n.includes('NILAM')) return { f: 'nilam', komp: 'EKSTRA' };
    if (n.includes('TIMSS') || n.includes('PISA')) return { f: 'timss', komp: 'EKSTRA' };
    if (n.includes('JAWATAN KHAS') || n.includes('PERKHIDMATAN') || n.includes('EKSTRA')) return { f: 'aktiviti', komp: 'EKSTRA' };
    let komp = null;
    if (/UNIFORM/.test(n)) komp = 'UNIFORM';
    else if (/SUKAN|PERMAINAN/.test(n)) komp = 'SUKAN';
    else if (/KELAB|PERSATUAN/.test(n)) komp = 'KELAB';
    if (!komp) return null;
    let f = 'aktiviti';
    if (n.includes('JAWATAN')) f = 'jawatan';
    else if (n.includes('PELIBATAN')) f = 'pelibatan';
    else if (n.includes('PENCAPAIAN')) f = 'pencapaian';
    else if (n.includes('KOMITMEN')) f = 'komitmen';
    else if (n.includes('KHIDMAT')) f = 'khidmat';
    else if (n.includes('KEHADIRAN')) f = 'kehadiran';
    return { f, komp };
  }

  // rows: array of arrays (baris pertama yang ada lajur IC dianggap tajuk)
  function rowsToStudents(rows) {
    let hi = -1, cols = null;
    for (let i = 0; i < Math.min(rows.length, 15); i++) {
      const c = (rows[i] || []).map(classifyHeader);
      if (c.some((x) => x && x.f === 'ic')) { hi = i; cols = c; break; }
    }
    if (hi < 0) throw new Error('Lajur No. KP / IC tidak dijumpai dalam fail. Pastikan baris tajuk ada lajur "IC" atau "No. KP".');
    const students = {};
    const found = new Set();
    cols.forEach((c) => c && found.add(c.komp ? c.komp + '.' + c.f : c.f));
    let count = 0;
    for (let i = hi + 1; i < rows.length; i++) {
      const r = rows[i] || [];
      let ic = '';
      const st = { nama: '', kelas: '', jawatanKhas: '', komponen: {} };
      cols.forEach((c, j) => {
        if (!c) return;
        const v = r[j] == null ? '' : String(r[j]).trim();
        if (c.f === 'ic') ic = normIC(v);
        else if (!c.komp) st[c.f] = v;
        else {
          st.komponen[c.komp] = st.komponen[c.komp] || {};
          if (!isBlank(v)) st.komponen[c.komp][c.f] = v;
        }
      });
      if (ic.length < 6) continue;
      students[ic] = st;
      count++;
    }
    return { students, count, columns: Array.from(found) };
  }

  // ---------- Slip Infomurid Kelas (2 baris tajuk; 10 lajur bagi setiap komponen) ----------
  const SLIP_PERINGKAT = { 'SEKOLAH': 'SEKOLAH', 'ZON/DAERAH': 'ZON/DAERAH', 'ZON': 'ZON/DAERAH', 'DAERAH': 'ZON/DAERAH',
    'NEGERI/BAHAGIAN': 'NEGERI', 'NEGERI': 'NEGERI', 'BAHAGIAN': 'BAHAGIAN (SABAH/SARAWAK)', 'KEBANGSAAN': 'KEBANGSAAN', 'ANTARABANGSA': 'ANTARABANGSA' };
  function slipPeringkat(v) { const n = norm(v).replace(/\s*\/\s*/g, '/'); return SLIP_PERINGKAT[n] || peringkatOf(n) || ''; }
  function slipKedudukan(v) {
    const n = norm(v).replace(/^TEMPAT\s+/, '');
    if (!n) return '';
    if (n === 'JOHAN' || n === 'PERTAMA') return 'JOHAN';
    if (n.startsWith('NAIB') || n === 'KEDUA') return 'NAIB JOHAN';
    if (n.startsWith('KETIGA')) return 'KETIGA';
    if (n.startsWith('KEEMPAT')) return 'KEEMPAT';
    if (n.startsWith('KELIMA')) return 'KELIMA';
    return KEDUDUKAN_ALIAS[n] || '';
  }
  function num(v) { const n = parseFloat(String(v == null ? '' : v).replace(',', '.')); return isNaN(n) ? null : n; }

  function isSlip(rows) {
    const r0 = (rows[0] || []).map(norm).join('|'), r1 = (rows[1] || []).map(norm).join('|');
    return /KAD PENGENALAN/.test(r0) && /KELAB DAN PERSATUAN/.test(r0) && /UNIT/.test(r1) && /PELIBATAN/.test(r1);
  }

  function parseSlip(rows) {
    let h = -1;
    for (let i = 0; i < Math.min(rows.length, 10); i++) if ((rows[i] || []).some((c) => /KAD PENGENALAN/.test(norm(c)))) { h = i; break; }
    if (h < 0 || !rows[h + 1]) throw new Error('Bukan fail Slip Infomurid Kelas (tiada tajuk "Kad Pengenalan" / "KELAB DAN PERSATUAN").');
    const r0 = rows[h].map(norm), r1 = rows[h + 1].map(norm);
    const col = (re, row) => row.findIndex((c) => re.test(c));
    const cIC = col(/KAD PENGENALAN/, r0), cNama = col(/^NAMA/, r0), cKelas = col(/^KELAS$/, r0);
    const sections = { KELAB: col(/KELAB DAN PERSATUAN/, r0), UNIFORM: col(/BADAN BERUNIFORM/, r0), SUKAN: col(/SUKAN DAN PERMAINAN/, r0) };
    const cBonus = col(/BONUS/, r0);
    for (const k in sections) if (sections[k] < 0) throw new Error('Lajur "' + k + '" tidak dijumpai dalam slip.');
    // dalam setiap bahagian, cari lajur ikut tajuk baris kedua
    const starts = Object.values(sections).concat([cBonus >= 0 ? cBonus : r1.length]).sort((x, y) => x - y);
    function sub(start) {
      const m = {}; let lastField = null;
      const end = starts.find((x) => x > start) || r1.length; // hanya lajur bahagian ini
      for (let j = start; j < end && j < r1.length; j++) {
        const t = r1[j];
        if (t === 'UNIT') m.unit = j;
        else if (t === 'KEHADIRAN') m.kehadiran = j;
        else if (t === 'JAWATAN') { m.jawatan = j; lastField = 'jawatan'; continue; }
        else if (t === 'PELIBATAN') { m.pelibatan = j; lastField = 'pelibatan'; continue; }
        else if (t === 'PENCAPAIAN') { m.pencapaian = j; lastField = 'pencapaian'; continue; }
        else if (t === 'SKOR' && lastField) { m[lastField + 'Skor'] = j; }
        lastField = null;
      }
      return m;
    }
    const map = {}; for (const k in sections) map[k] = sub(sections[k]);
    let bJ = -1, bS = -1;
    if (cBonus >= 0) { bJ = r1.indexOf('JAWATAN', cBonus); bS = r1.indexOf('SKOR', cBonus); }
    const students = {}; let count = 0;
    for (let i = h + 2; i < rows.length; i++) {
      const r = rows[i] || [];
      const ic = normIC(r[cIC]);
      if (ic.length < 6) continue;
      const st = { nama: String(r[cNama] || '').replace(/[\u2018\u2019]/g, "'").trim(), kelas: String(r[cKelas] || '').trim(), slip: true, komponen: {} };
      for (const k in map) {
        const m = map[k], g = (j) => (j == null ? '' : String(r[j] == null ? '' : r[j]).trim());
        const c = {};
        if (g(m.unit)) {
          c.aktiviti = g(m.unit);
          if (g(m.jawatan)) { c.jawatan = g(m.jawatan); c.jawatanSkor = num(g(m.jawatanSkor)); }
          const pr = slipPeringkat(g(m.pelibatan));
          if (pr) { c.pelibatan = pr; c.pelibatanSkor = num(g(m.pelibatanSkor)); }
          const kd = slipKedudukan(g(m.pencapaian));
          if (kd) { c.pencapaian = kd; c.pencapaianSkor = num(g(m.pencapaianSkor)); }
          const kh = num(g(m.kehadiran));
          if (kh != null) { c.kehadiran = String(kh); c.kehadiranSkor = kh; }
        }
        st.komponen[k] = c;
      }
      const jk = bJ >= 0 ? String(r[bJ] || '').trim() : '';
      st.komponen.EKSTRA = jk ? { aktiviti: jk, perkhidmatanSkor: bS >= 0 ? num(r[bS]) : null } : {};
      students[ic] = st; count++;
    }
    return { students, count, columns: ['slip'] };
  }

  // Nama jawatan slip → calon nama jawatan SPPB (dicuba mengikut urutan)
  function slipJawatanAlts(name) {
    const n = norm(name).replace(/SETIUSAHA/g, 'SETIAUSAHA');
    const core = n.replace(/\s+UNIT UNIFORM,?\s*PERSATUAN\s*(&|DAN)\s*KELAB\s*$/, '').trim();
    const alts = [n, core];
    if (/^AJK\b|^A\.?J\.?K\b|JAWATANKUASA/.test(core)) alts.push('AHLI JAWATANKUASA');
    if (core === 'AHLI AKTIF') alts.push('AHLI AKTIF');
    return Array.from(new Set(alts.filter(Boolean)));
  }

  function parseCSV(text) {
    const rows = [];
    let row = [], cur = '', q = false;
    const delim = (text.split('\n')[0].match(/\t/g) || []).length > (text.split('\n')[0].match(/,/g) || []).length ? '\t'
      : ((text.split('\n')[0].match(/;/g) || []).length > (text.split('\n')[0].match(/,/g) || []).length ? ';' : ',');
    for (let i = 0; i < text.length; i++) {
      const ch = text[i];
      if (q) {
        if (ch === '"') { if (text[i + 1] === '"') { cur += '"'; i++; } else q = false; }
        else cur += ch;
      } else if (ch === '"') q = true;
      else if (ch === delim) { row.push(cur); cur = ''; }
      else if (ch === '\n') { row.push(cur.replace(/\r$/, '')); rows.push(row); row = []; cur = ''; }
      else cur += ch;
    }
    if (cur !== '' || row.length) { row.push(cur.replace(/\r$/, '')); rows.push(row); }
    return rows;
  }

  function toCSV(rows) {
    return rows.map((r) => r.map((c) => {
      const s = String(c == null ? '' : c);
      return /[",\n\r]/.test(s) ? '"' + s.replace(/"/g, '""') + '"' : s;
    }).join(',')).join('\r\n');
  }

  // Gabung data murid + nilai lalai bagi satu komponen
  function effectiveFor(student, defaults, komp) {
    const d = (defaults && defaults[komp]) || {};
    let s = (student && student.komponen && student.komponen[komp]) || {};
    if (student && student.slip) {
      const out = {};
      for (const f of FIELDS) {
        if (komp !== 'EKSTRA' && SLIP_FIELDS.includes(f)) {
          if (!isBlank(s[f])) out[f] = s[f];
          else if (f === 'jawatan' && !isBlank(s.aktiviti) && !isBlank(d.jawatan)) out[f] = d.jawatan; // SPPB wajibkan jawatan
          // Pelibatan / Pencapaian / Kehadiran kosong dalam slip → nilai lalai (jika tetapan membenarkan)
          else if ((f === 'pelibatan' || f === 'pencapaian' || f === 'kehadiran') && !isBlank(s.aktiviti) && !isBlank(d[f]) && !(defaults && defaults.__slipUseDefaults === false)) out[f] = d[f];
          continue;
        }
        if (komp === 'EKSTRA' && f === 'aktiviti') { out[f] = isBlank(s[f]) ? '__CLEAR__' : s[f]; continue; }
        if (!isBlank(s[f])) out[f] = s[f];
        else if (f !== 'aktiviti' && !isBlank(d[f])) out[f] = d[f];
      }
      out.__slip = s; // markah rujukan daripada slip (jawatanSkor, pelibatanSkor, pencapaianSkor, kehadiranSkor, perkhidmatanSkor)
      return out;
    }
    // data yang diimport dengan versi lama: Jawatan Khas disimpan sebagai student.jawatanKhas
    if (komp === 'EKSTRA' && isBlank(s.aktiviti) && student && !isBlank(student.jawatanKhas)) s = Object.assign({}, s, { aktiviti: student.jawatanKhas });
    const out = {};
    for (const f of FIELDS) {
      if (!isBlank(s[f])) out[f] = s[f];
      else if ((f !== 'aktiviti' || komp === 'EKSTRA') && !isBlank(d[f])) out[f] = d[f];
    }
    return out;
  }

  const DEFAULT_SETTINGS = {
    overwrite: false,          // ganti komponen yang sudah ada aktiviti
    fillDefaultsOnly: false,   // isi pukal: murid tiada dalam data → isi nilai lalai sahaja? (perlu aktiviti sedia ada)
    skipNoData: true,          // isi pukal: langkau murid yang tiada dalam data
    stepDelay: 250,            // ms antara klik
    stopOnError: true,
    slipUseDefaults: true      // data slip: guna nilai lalai bagi Pelibatan/Pencapaian/Kehadiran yang kosong dalam slip
  };

  const DEFAULTS_TEMPLATE = {
    KELAB: { jawatan: '', pelibatan: '', pencapaian: '', komitmen: '', khidmat: '', kehadiran: '' },
    UNIFORM: { jawatan: '', pelibatan: '', pencapaian: '', komitmen: '', khidmat: '', kehadiran: '' },
    SUKAN: { jawatan: '', pelibatan: '', pencapaian: '', komitmen: '', khidmat: '', kehadiran: '' },
    EKSTRA: { aktiviti: '', anugerah: '', khidmatMasyarakat: '', nilam: '', timss: '' }
  };

  root.PP = {
    KOMPONEN, KOMPONEN_KEYS, MAIN_KEYS, FIELDS, EKSTRA_FIELDS, ANUGERAH, ARP_TAHAP, KHIDMAT_MASYARAKAT, PERKHIDMATAN, TIMSS_PISA, JAWATAN_UMUM,
    parseAnugerah, parseKhidmatMasyarakat, parseNilam, FIELD_LABEL, PERINGKAT, KEDUDUKAN,
    norm, normIC, tokens, similarity, bestMatch, matchPerkhidmatan, matchFor, parseMapping,
    splitList, peringkatOf, parsePelibatan, parsePencapaian, parseKehadiran, isBlank,
    classifyHeader, rowsToStudents, parseCSV, toCSV, effectiveFor, isSlip, parseSlip, slipJawatanAlts, slipKedudukan, slipPeringkat, scoreOf, SLIP_FIELDS,
    DEFAULT_SETTINGS, DEFAULTS_TEMPLATE
  };
})(typeof globalThis !== 'undefined' ? globalThis : this);
