// PAJSK Pembantu — dijalankan dalam konteks halaman (MAIN world).
// Tujuan: mengesan sama ada permintaan SIMPAN ke pelayan SPPB berjaya atau gagal,
// supaya isi pukal boleh berhenti jika ada ralat. Tiada data dihantar ke luar.
(function () {
  if (window.__pajskPembantuHook) return;
  window.__pajskPembantuHook = true;

  const WATCH = /pajsk/i;

  function report(method, url, status, body) {
    try {
      window.postMessage(
        {
          __pajskPembantu: true,
          type: 'net',
          method: String(method || 'GET').toUpperCase(),
          url: String(url || ''),
          status: status,
          body: typeof body === 'string' ? body.slice(0, 4000) : ''
        },
        '*'
      );
    } catch (e) { /* abaikan */ }
  }

  // ---- Kosongkan dropdown Wave UI (w-select) melalui instans Vue 3 ----
  // Dropdown SPPB tiada butang "x"; nilai hanya boleh dikosongkan melalui komponen itu sendiri.
  function findSelectInstance(el) {
    const host = el.closest('.w-select') || el;
    // 1) binaan dev: el.__vueParentComponent
    for (let n = host; n; n = n.parentElement) {
      let inst = n.__vueParentComponent;
      while (inst) {
        const name = (inst.type && (inst.type.name || inst.type.__name)) || '';
        if (/w-?select/i.test(name) && inst.subTree && inst.subTree.el && (inst.subTree.el === host || (inst.subTree.el.contains && inst.subTree.el.contains(host)))) return inst;
        inst = inst.parent;
      }
    }
    // 2) binaan produksi: telusuri pokok vnode dari app.__vue_app__
    // (app._instance hanya wujud dalam binaan dev; container._vnode wujud dalam semua binaan)
    const appEl = document.querySelector('[data-v-app]') || document.getElementById('app');
    const app = appEl && appEl.__vue_app__;
    const rootVNode = appEl && appEl._vnode;
    const root = (app && app._instance) || (rootVNode && rootVNode.component);
    if (!root) return null;
    let found = null;
    const seen = new Set();
    function walkInst(inst) {
      if (!inst || found || seen.has(inst)) return;
      seen.add(inst);
      const name = (inst.type && (inst.type.name || inst.type.__name)) || '';
      const rootEl = inst.subTree && inst.subTree.el;
      if (/w-?select/i.test(name) && rootEl && rootEl.nodeType === 1 && (rootEl === host || rootEl.contains(host) || host.contains(rootEl))) { found = inst; return; }
      walkVNode(inst.subTree);
    }
    function walkVNode(v) {
      if (!v || found) return;
      if (v.component) walkInst(v.component);
      if (v.suspense && v.suspense.activeBranch) walkVNode(v.suspense.activeBranch);
      if (Array.isArray(v.children)) v.children.forEach((c) => c && typeof c === 'object' && walkVNode(c));
      if (v.dynamicChildren) v.dynamicChildren.forEach(walkVNode);
    }
    walkInst(root);
    return found;
  }

  window.addEventListener('message', (ev) => {
    const d = ev.data;
    if (!d || d.__pajskPembantu !== true || d.type !== 'clearSelect') return;
    let ok = false, how = '';
    try {
      const el = document.getElementById(d.id);
      if (!el) how = 'elemen tiada';
      else {
        const inst = findSelectInstance(el);
        if (inst) {
          const empty = d.multiple ? [] : null;
          const px = inst.proxy;
          if (px && typeof px.onReset === 'function') { px.onReset(); how = 'onReset'; }
          if (inst.props && inst.props.modelValue !== null && inst.props.modelValue !== undefined && inst.props.modelValue !== '' && typeof inst.emit === 'function') {
            inst.emit('update:modelValue', empty); inst.emit('input', empty); how = how || 'emit';
          }
          // paparan dalaman Wave UI (inputValue) tidak dikemas kini oleh watcher apabila nilai null
          if (inst.data && Array.isArray(inst.data.inputValue) && inst.data.inputValue.length) inst.data.inputValue = [];
          ok = true;
        } else how = 'komponen Vue tidak dijumpai';
      }
    } catch (e) { how = 'ralat: ' + e.message; }
    window.postMessage({ __pajskPembantu: true, type: 'clearSelectResult', reqId: d.reqId, ok, how }, '*');
  });

  // XMLHttpRequest (axios / Inertia)
  const XO = XMLHttpRequest.prototype.open;
  const XS = XMLHttpRequest.prototype.send;
  XMLHttpRequest.prototype.open = function (method, url) {
    this.__pp = { method: method, url: url };
    return XO.apply(this, arguments);
  };
  XMLHttpRequest.prototype.send = function () {
    const info = this.__pp;
    if (info && WATCH.test(String(info.url)) && String(info.method).toUpperCase() !== 'GET') {
      this.addEventListener('loadend', () => {
        let body = '';
        try { body = this.responseType === '' || this.responseType === 'text' ? this.responseText : ''; } catch (e) {}
        report(info.method, info.url, this.status, body);
      });
    }
    return XS.apply(this, arguments);
  };

  // fetch
  const F = window.fetch;
  if (F) {
    window.fetch = function (input, init) {
      const url = typeof input === 'string' ? input : (input && input.url) || '';
      const method = (init && init.method) || (input && input.method) || 'GET';
      const p = F.apply(this, arguments);
      if (WATCH.test(url) && String(method).toUpperCase() !== 'GET') {
        p.then(
          (r) => r.clone().text().then((t) => report(method, url, r.status, t), () => report(method, url, r.status, '')),
          () => report(method, url, 0, '')
        );
      }
      return p;
    };
  }
})();
