chrome.storage.local.get(['pp_meta', 'pp_batch'], (d) => {
  const m = d.pp_meta;
  let t = m ? m.count + ' murid dalam data' + (m.fileName ? ' (' + m.fileName + ')' : '') : 'Belum ada data murid diimport.';
  if (d.pp_batch && d.pp_batch.active) t += ' · Isi pukal sedang berjalan (' + (d.pp_batch.index + 1) + '/' + d.pp_batch.queue.length + ')';
  document.getElementById('info').textContent = t;
});
document.getElementById('opts').onclick = () => chrome.runtime.openOptionsPage();
document.getElementById('toggle').onclick = async () => {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (!tab || !/^https:\/\/moeissppb\.moe\.gov\.my\//.test(tab.url || '')) {
    document.getElementById('info').textContent = 'Buka laman SPPB (moeissppb.moe.gov.my) dahulu.';
    return;
  }
  chrome.tabs.sendMessage(tab.id, { type: 'togglePanel' }, () => {
    if (chrome.runtime.lastError) {
      document.getElementById('info').textContent = 'Halaman SPPB ini dibuka sebelum extension dipasang. Tekan F5 (muat semula halaman), kemudian cuba lagi.';
      return;
    }
    window.close();
  });
};

// ---- Kemas kini ----
function esc(s) { return String(s == null ? '' : s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c])); }
function showUpdate(r) {
  const box = document.getElementById('updateBanner');
  if (!r || !r.hasUpdate) { box.classList.add('hidden'); return; }
  const notes = Array.isArray(r.info.notes) ? r.info.notes : (r.info.notes ? [r.info.notes] : []);
  box.innerHTML = '<b>🔔 Versi ' + esc(r.latest) + ' tersedia</b> (anda: ' + esc(r.current) + ')' +
    (notes.length ? '<ul>' + notes.slice(0, 5).map((n) => '<li>' + esc(n) + '</li>').join('') + '</ul>' : '') +
    '<button id="btnUpdate" type="button">Muat turun versi baharu</button>' +
    '<ol><li>Unzip dan gantikan fail dalam folder extension lama.</li><li>Buka <b>chrome://extensions</b> → tekan ↻ Reload.</li><li>Tekan F5 pada halaman SPPB.</li></ol>';
  box.classList.remove('hidden');
  document.getElementById('btnUpdate').onclick = () => chrome.tabs.create({ url: r.info.zip });
}
document.getElementById('verLabel').textContent = 'v' + chrome.runtime.getManifest().version;
chrome.runtime.sendMessage({ type: 'checkUpdate', force: false }, (r) => { void chrome.runtime.lastError; if (r && !r.error) showUpdate(r); });
document.getElementById('lnkUpdate').onclick = (ev) => {
  ev.preventDefault();
  const a = ev.target; a.textContent = 'Menyemak…';
  chrome.runtime.sendMessage({ type: 'checkUpdate', force: true }, (r) => {
    void chrome.runtime.lastError;
    if (!r || r.error) { a.textContent = 'Gagal semak' + (r && r.error ? ' (' + r.error + ')' : ''); return; }
    showUpdate(r);
    a.textContent = r.hasUpdate ? 'Versi baharu tersedia ↑' : 'Sudah versi terkini ✓';
  });
};
