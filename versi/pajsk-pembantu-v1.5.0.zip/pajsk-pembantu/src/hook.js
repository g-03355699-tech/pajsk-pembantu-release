// PAJSK Pembantu — dijalankan dalam konteks halaman (MAIN world).
// Tujuan: mengesan sama ada permintaan SIMPAN ke pelayan SPPB berjaya atau gagal,
// supaya isi pukal boleh berhenti jika ada ralat. Tiada data dihantar ke luar.
(function () {
  if (window.__pajskPembantuHook) return;
  window.__pajskPembantuHook = true;

  const WATCH = /pajsk/i;

  function report(method, url, status, body) {
    try {
      window.postMessage(
        {
          __pajskPembantu: true,
          type: 'net',
          method: String(method || 'GET').toUpperCase(),
          url: String(url || ''),
          status: status,
          body: typeof body === 'string' ? body.slice(0, 4000) : ''
        },
        '*'
      );
    } catch (e) { /* abaikan */ }
  }

  // XMLHttpRequest (axios / Inertia)
  const XO = XMLHttpRequest.prototype.open;
  const XS = XMLHttpRequest.prototype.send;
  XMLHttpRequest.prototype.open = function (method, url) {
    this.__pp = { method: method, url: url };
    return XO.apply(this, arguments);
  };
  XMLHttpRequest.prototype.send = function () {
    const info = this.__pp;
    if (info && WATCH.test(String(info.url)) && String(info.method).toUpperCase() !== 'GET') {
      this.addEventListener('loadend', () => {
        let body = '';
        try { body = this.responseType === '' || this.responseType === 'text' ? this.responseText : ''; } catch (e) {}
        report(info.method, info.url, this.status, body);
      });
    }
    return XS.apply(this, arguments);
  };

  // fetch
  const F = window.fetch;
  if (F) {
    window.fetch = function (input, init) {
      const url = typeof input === 'string' ? input : (input && input.url) || '';
      const method = (init && init.method) || (input && input.method) || 'GET';
      const p = F.apply(this, arguments);
      if (WATCH.test(url) && String(method).toUpperCase() !== 'GET') {
        p.then(
          (r) => r.clone().text().then((t) => report(method, url, r.status, t), () => report(method, url, r.status, '')),
          () => report(method, url, 0, '')
        );
      }
      return p;
    };
  }
})();
