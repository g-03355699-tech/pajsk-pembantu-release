// PAJSK Pembantu — service worker
importScripts('update.js');

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (!msg) return;
  if (msg.type === 'openOptions') chrome.runtime.openOptionsPage();
  if (msg.type === 'openUrl' && /^https:\/\/(github\.com|raw\.githubusercontent\.com)\//.test(msg.url || '')) chrome.tabs.create({ url: msg.url });
  if (msg.type === 'checkUpdate') {
    checkUpdate(!!msg.force).then(sendResponse, (e) => sendResponse({ error: String(e.message || e) }));
    return true; // jawapan tak segerak
  }
});

function scheduled() { checkUpdate(false).catch(() => {}); }
chrome.runtime.onInstalled.addListener(() => {
  chrome.alarms.create('pp-update', { periodInMinutes: 360 });
  checkUpdate(true).catch(() => {});
});
chrome.runtime.onStartup.addListener(scheduled);
chrome.alarms.onAlarm.addListener((a) => { if (a.name === 'pp-update') scheduled(); });
