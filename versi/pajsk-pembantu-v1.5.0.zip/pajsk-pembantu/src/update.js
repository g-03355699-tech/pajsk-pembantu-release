/* PAJSK Pembantu — semakan versi baharu (dijalankan dalam service worker)
 * Membaca latest.json dari repo awam pajsk-pembantu-release.
 * Tiada kod dimuat turun atau dijalankan; hanya nombor versi, nota dan pautan.
 */
'use strict';

const UPDATE_URL = 'https://raw.githubusercontent.com/g-03355699-tech/pajsk-pembantu-release/main/latest.json';
const UPDATE_PAGE = 'https://github.com/g-03355699-tech/pajsk-pembantu-release';
const CHECK_EVERY_MS = 6 * 60 * 60 * 1000; // 6 jam

function cmpVer(a, b) {
  const pa = String(a).split('.').map(Number), pb = String(b).split('.').map(Number);
  for (let i = 0; i < Math.max(pa.length, pb.length); i++) {
    const d = (pa[i] || 0) - (pb[i] || 0);
    if (d) return d;
  }
  return 0;
}

function safeZip(info) {
  return /^https:\/\/(github\.com|raw\.githubusercontent\.com|objects\.githubusercontent\.com)\//.test((info && info.zip) || '') ? info.zip : UPDATE_PAGE;
}

async function setBadge(info) {
  const cur = chrome.runtime.getManifest().version;
  const has = info && info.version && cmpVer(info.version, cur) > 0;
  await chrome.action.setBadgeText({ text: has ? 'NEW' : '' });
  if (has) await chrome.action.setBadgeBackgroundColor({ color: '#d97706' });
}

// Pulangkan { current, latest, hasUpdate, info }
async function checkUpdate(force) {
  const now = Date.now();
  const cur = chrome.runtime.getManifest().version;
  const st = await chrome.storage.local.get(['updLast', 'updInfo']);
  let info = st.updInfo;
  if (force || !info || !st.updLast || now - st.updLast >= CHECK_EVERY_MS) {
    const res = await fetch(UPDATE_URL + '?t=' + now, { cache: 'no-store' });
    if (!res.ok) throw new Error('HTTP ' + res.status);
    info = await res.json();
    await chrome.storage.local.set({ updLast: now, updInfo: info });
  }
  await setBadge(info);
  return {
    current: cur,
    latest: info && info.version,
    hasUpdate: !!(info && info.version && cmpVer(info.version, cur) > 0),
    info: info ? Object.assign({}, info, { zip: safeZip(info) }) : null
  };
}
