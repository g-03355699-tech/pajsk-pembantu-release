/* PAJSK Pembantu — halaman tetapan */
(function () {
  'use strict';
  const PP = globalThis.PP;
  const $ = (id) => document.getElementById(id);
  const store = {
    get: (k) => new Promise((r) => chrome.storage.local.get(k, r)),
    set: (o) => new Promise((r) => chrome.storage.local.set(o, r)),
    remove: (k) => new Promise((r) => chrome.storage.local.remove(k, r))
  };

  const KOMITMEN = ['MENUNJUKKAN KEPIMPINAN', 'MENGURUS AKTIVITI', 'MENYEDIA PERALATAN', 'MEMBANTU GURU ATAU RAKAN', 'MENGEMAS PERALATAN',
    'MEMBERSIH KAWASAN', 'MENEPATI WAKTU', 'MENUNJUKKAN MINAT', 'MENUNJUKKAN KESUNGGUHAN', 'MENGIKUT ARAHAN', 'MENCUBA', 'MEMBERI KERJASAMA',
    'MANA-MANA NILAI MURNI YANG BOLEH DIPERHATIKAN'];
  const KHIDMAT = ['Didaftarkan sebagai atlet / peserta program, pertandingan, karnival, kursus',
    'Kemahiran khusus — aspek teknikal (pengadil, jurulatih pasukan, dll.)',
    'Terlibat dalam aktiviti seperti persembahan selingan',
    'Membantu menjayakan aktiviti (perbarisan, persembahan, kumpulan sorak, dll.)'];

  $('ver').textContent = chrome.runtime.getManifest().version;

  function status(id, msg, ok) {
    const e = $(id); e.textContent = msg; e.className = 'status' + (e.classList.contains('inline') ? ' inline' : '') + (ok === false ? ' err' : ' ok');
    if (e.classList.contains('inline')) setTimeout(() => { if (e.textContent === msg) e.textContent = ''; }, 3000);
  }
  // kekalkan kelas inline
  ['defStatus', 'mapStatus', 'setStatus'].forEach((i) => $(i).classList.add('inline'));

  // ------------------------------------------------------------------
  // Import
  // ------------------------------------------------------------------
  async function importRows(rows, fileName) {
    try {
      const r = PP.rowsToStudents(rows);
      if (!r.count) throw new Error('Tiada baris murid yang sah (No. KP sekurang-kurangnya 6 digit).');
      let students = r.students;
      if ($('appendMode').checked) {
        const d = await store.get(['pp_students']);
        students = Object.assign({}, d.pp_students || {}, r.students);
      }
      const meta = { fileName, count: Object.keys(students).length, importedAt: Date.now(), columns: r.columns };
      await store.set({ pp_students: students, pp_meta: meta });
      status('importStatus', '✓ ' + r.count + ' murid diimport dari "' + fileName + '". Lajur dikenali: ' + r.columns.map(colName).join(', '), true);
      await renderPreview();
      await renderMatches();
    } catch (e) {
      status('importStatus', '✖ ' + e.message, false);
    }
  }

  function colName(c) {
    const [k, f] = c.split('.');
    if (!f) return ({ ic: 'No. KP', nama: 'Nama', kelas: 'Kelas', jawatanKhas: 'Jawatan Khas' })[k] || k;
    return PP.KOMPONEN[k].label.split(' ')[0] + ' – ' + PP.FIELD_LABEL[f];
  }

  $('file').addEventListener('change', async (ev) => {
    const f = ev.target.files[0];
    if (!f) return;
    try {
      const buf = await f.arrayBuffer();
      let rows;
      if (/\.(csv|txt)$/i.test(f.name)) {
        rows = PP.parseCSV(new TextDecoder('utf-8').decode(buf).replace(/^﻿/, ''));
      } else {
        const wb = XLSX.read(buf, { type: 'array', raw: true, cellText: true });
        const ws = wb.Sheets[wb.SheetNames[0]];
        rows = XLSX.utils.sheet_to_json(ws, { header: 1, raw: false, defval: '' });
      }
      await importRows(rows, f.name);
    } catch (e) {
      status('importStatus', '✖ Fail tidak dapat dibaca: ' + e.message, false);
    }
    ev.target.value = '';
  });

  $('btnPaste').onclick = () => { $('pasteBox').classList.toggle('hidden'); $('pasteArea').focus(); };
  $('btnPasteOk').onclick = () => {
    const t = $('pasteArea').value;
    if (!t.trim()) return;
    importRows(PP.parseCSV(t), 'Tampalan ' + new Date().toLocaleString('ms-MY'));
  };
  $('btnClear').onclick = async () => {
    if (!confirm('Padam semua data murid yang diimport?')) return;
    await store.remove(['pp_students', 'pp_meta']);
    status('importStatus', 'Data murid dipadam.', true);
    renderPreview(); renderMatches();
  };
  $('btnTemplate').onclick = () => {
    const head = ['IC', 'Nama'];
    const sample = ['120101101234', 'CONTOH NAMA MURID'];
    const sampleVals = {
      KELAB: ['KELAB KOPERASI', 'AHLI AKTIF', 'SEKOLAH:3', '', '7;8;10;12', '1', '12'],
      UNIFORM: ['PASUKAN KADET POLIS', 'AHLI AKTIF', 'SEKOLAH:3; ZON/DAERAH:1', 'ZON/DAERAH:JOHAN', '7;8;10;12', '4', '10'],
      SUKAN: ['KELAB CATUR', 'AHLI AKTIF', 'SEKOLAH:2', '', '7;8;10;12', '1', '12']
    };
    const names = { KELAB: 'Kelab', UNIFORM: 'Uniform', SUKAN: 'Sukan' };
    PP.KOMPONEN_KEYS.forEach((k) => {
      head.push(PP.KOMPONEN[k].label.replace(' & ', '/'), 'Jawatan ' + names[k], 'Pelibatan ' + names[k], 'Pencapaian ' + names[k], 'Komitmen ' + names[k], 'Khidmat ' + names[k], 'Kehadiran ' + names[k]);
      sample.push(...sampleVals[k]);
    });
    const csv = '﻿' + PP.toCSV([head, sample]);
    const a = document.createElement('a');
    a.href = URL.createObjectURL(new Blob([csv], { type: 'text/csv;charset=utf-8' }));
    a.download = 'templat_pajsk_pembantu.csv';
    a.click();
  };

  async function renderPreview() {
    const d = await store.get(['pp_students', 'pp_meta']);
    const s = d.pp_students || {};
    const t = $('preview');
    t.innerHTML = '';
    const ics = Object.keys(s);
    if (!ics.length) { $('importStatus').textContent || status('importStatus', 'Belum ada data diimport.', true); return; }
    if (!$('importStatus').textContent && d.pp_meta) status('importStatus', d.pp_meta.count + ' murid dimuatkan · ' + (d.pp_meta.fileName || '') + ' · ' + new Date(d.pp_meta.importedAt).toLocaleString('ms-MY'), true);
    const h = document.createElement('tr');
    ['No. KP', 'Nama', 'Kelab & Persatuan', 'Badan Beruniform', 'Sukan & Permainan', 'Jawatan Khas'].forEach((x) => { const th = document.createElement('th'); th.textContent = x; h.appendChild(th); });
    t.appendChild(h);
    ics.slice(0, 500).forEach((ic) => {
      const st = s[ic];
      const tr = document.createElement('tr');
      const cells = [ic, st.nama || ''].concat(PP.KOMPONEN_KEYS.map((k) => {
        const c = st.komponen[k] || {};
        const extra = ['jawatan', 'pelibatan', 'pencapaian', 'komitmen', 'khidmat', 'kehadiran'].filter((f) => c[f]).map((f) => PP.FIELD_LABEL[f] + ': ' + c[f]);
        return (c.aktiviti || '—') + (extra.length ? '\n' + extra.join(' · ') : '');
      }), [st.jawatanKhas || '']);
      cells.forEach((v) => { const td = document.createElement('td'); td.textContent = v; td.style.whiteSpace = 'pre-line'; tr.appendChild(td); });
      t.appendChild(tr);
    });
  }

  // ------------------------------------------------------------------
  // Nilai lalai
  // ------------------------------------------------------------------
  let defaults = JSON.parse(JSON.stringify(PP.DEFAULTS_TEMPLATE));
  let currentKomp = 'KELAB';
  let captured = {};

  function opt(sel, value, label, cur) {
    const o = document.createElement('option'); o.value = value; o.textContent = label; if (String(cur) === String(value)) o.selected = true; sel.appendChild(o); return o;
  }

  function splitPair(v) {
    const p = PP.splitList(v)[0] || '';
    const pe = PP.peringkatOf(p) || '';
    const rest = PP.norm(p).replace(/^[^:=]*[:=]?/, '').trim();
    return [pe, rest];
  }

  function renderDefTabs() {
    const box = $('defTabs'); box.innerHTML = '';
    PP.KOMPONEN_KEYS.forEach((k) => {
      const b = document.createElement('button');
      b.className = 'tab' + (k === currentKomp ? ' on' : '');
      b.textContent = PP.KOMPONEN[k].label;
      b.onclick = () => { readDefForm(); currentKomp = k; renderDefTabs(); renderDefForm(); };
      box.appendChild(b);
    });
  }

  function renderDefForm() {
    const d = defaults[currentKomp] || {};
    const f = $('defForm'); f.innerHTML = '';
    const g = document.createElement('div'); g.className = 'grid'; f.appendChild(g);
    const row = (label, node) => { const l = document.createElement('label'); l.textContent = label; g.appendChild(l); g.appendChild(node); };

    // Jawatan
    const jw = document.createElement('input'); jw.type = 'text'; jw.id = 'd_jawatan'; jw.value = d.jawatan || ''; jw.placeholder = 'cth. AHLI AKTIF';
    jw.setAttribute('list', 'dl_jawatan');
    const dl = document.createElement('datalist'); dl.id = 'dl_jawatan';
    ((captured.jawatan && captured.jawatan[currentKomp]) || []).forEach((x) => opt(dl, x, x));
    const jwBox = document.createElement('div'); jwBox.className = 'inl'; jwBox.append(jw, dl);
    if (!(captured.jawatan && captured.jawatan[currentKomp])) { const s = document.createElement('span'); s.className = 'muted'; s.textContent = 'Senarai jawatan SPPB akan muncul selepas extension membuka dropdown jawatan sekali.'; jwBox.appendChild(s); }
    row('Jawatan', jwBox);

    // Pelibatan
    const [pp, pn] = splitPair(d.pelibatan);
    const pelBox = document.createElement('div'); pelBox.className = 'inl';
    const pSel = document.createElement('select'); pSel.id = 'd_pel_p'; opt(pSel, '', '— tidak diisi —', pp);
    PP.PERINGKAT.forEach((x) => opt(pSel, x.label, x.label, pp));
    const nSel = document.createElement('select'); nSel.id = 'd_pel_n';
    [1, 2, 3].forEach((n) => opt(nSel, n, 'Pelibatan ' + n, pn || 1));
    pelBox.append(pSel, nSel);
    row('Pelibatan', pelBox);

    // Pencapaian
    const [cp, cn] = splitPair(d.pencapaian);
    const capBox = document.createElement('div'); capBox.className = 'inl';
    const cSel = document.createElement('select'); cSel.id = 'd_cap_p'; opt(cSel, '', '— tidak diisi —', cp);
    PP.PERINGKAT.forEach((x) => opt(cSel, x.label, x.label, cp));
    const kSel = document.createElement('select'); kSel.id = 'd_cap_k';
    PP.KEDUDUKAN.forEach((x) => opt(kSel, x, x, cn || 'JOHAN'));
    capBox.append(cSel, kSel);
    row('Pencapaian', capBox);

    // Komitmen
    const chosen = PP.splitList(d.komitmen).map((x) => /^\d+$/.test(x) ? parseInt(x, 10) : KOMITMEN.findIndex((k) => k.includes(PP.norm(x))) + 1);
    const kb = document.createElement('div'); kb.className = 'komit'; kb.id = 'd_komit';
    KOMITMEN.forEach((k, i) => {
      const l = document.createElement('label'); l.className = 'chk';
      const c = document.createElement('input'); c.type = 'checkbox'; c.value = String(i + 1); c.checked = chosen.includes(i + 1);
      c.onchange = () => { const on = kb.querySelectorAll('input:checked'); if (on.length > 4) { c.checked = false; alert('Maksimum 4 pilihan komitmen.'); } };
      l.append(c, document.createTextNode((i + 1) + '. ' + k)); kb.appendChild(l);
    });
    row('Komitmen (maks. 4)', kb);

    // Khidmat
    const kh = document.createElement('select'); kh.id = 'd_khidmat'; opt(kh, '', '— tidak diisi —', d.khidmat || '');
    KHIDMAT.forEach((x, i) => opt(kh, String(i + 1), (i + 1) + '. ' + x, d.khidmat || ''));
    row('Khidmat sumbangan', kh);

    // Kehadiran
    const hd = document.createElement('select'); hd.id = 'd_kehadiran'; opt(hd, '', '— tidak diisi —', d.kehadiran === undefined ? '' : d.kehadiran);
    for (let i = 12; i >= 0; i--) opt(hd, String(i), String(i), d.kehadiran === undefined ? '' : d.kehadiran);
    row('Kehadiran', hd);

    const copy = document.createElement('button'); copy.className = 'btn'; copy.textContent = 'Salin nilai ini ke semua komponen';
    copy.onclick = () => { readDefForm(); PP.KOMPONEN_KEYS.forEach((k) => { if (k !== currentKomp) defaults[k] = Object.assign({}, defaults[currentKomp]); }); status('defStatus', 'Disalin — tekan Simpan.', true); };
    row('', copy);
  }

  function readDefForm() {
    if (!$('d_jawatan')) return;
    const p = $('d_pel_p').value, c = $('d_cap_p').value;
    defaults[currentKomp] = {
      jawatan: $('d_jawatan').value.trim(),
      pelibatan: p ? p + ':' + $('d_pel_n').value : '',
      pencapaian: c ? c + ':' + $('d_cap_k').value : '',
      komitmen: Array.from($('d_komit').querySelectorAll('input:checked')).map((x) => x.value).join(';'),
      khidmat: $('d_khidmat').value,
      kehadiran: $('d_kehadiran').value
    };
  }

  $('btnSaveDef').onclick = async () => { readDefForm(); await store.set({ pp_defaults: defaults }); status('defStatus', '✓ Disimpan', true); };

  // ------------------------------------------------------------------
  // Padanan
  // ------------------------------------------------------------------
  async function renderMatches() {
    const d = await store.get(['pp_students', 'pp_options', 'pp_mapping']);
    captured = d.pp_options || {};
    const mapping = PP.parseMapping(d.pp_mapping || '');
    const s = d.pp_students || {};
    const box = $('matchTable'); box.innerHTML = '';
    const uniq = {};
    Object.values(s).forEach((st) => PP.KOMPONEN_KEYS.forEach((k) => {
      const a = st.komponen[k] && st.komponen[k].aktiviti;
      if (a) { uniq[k] = uniq[k] || {}; uniq[k][PP.norm(a)] = (uniq[k][PP.norm(a)] || 0) + 1; }
    }));
    if (!Object.keys(uniq).length) { box.innerHTML = '<p class="muted">Import data dahulu untuk melihat padanan.</p>'; return; }
    const t = document.createElement('table'); t.className = 'match';
    t.innerHTML = '<tr><th>Komponen</th><th>Nama dalam fail</th><th>Murid</th><th>Pilihan SPPB</th><th>Status</th></tr>';
    PP.KOMPONEN_KEYS.forEach((k) => {
      const opts = (captured.aktiviti && captured.aktiviti[k]) || [];
      Object.keys(uniq[k] || {}).sort().forEach((name) => {
        const tr = document.createElement('tr');
        const m = opts.length ? PP.bestMatch(name, opts, mapping) : null;
        const td = (x) => { const e = document.createElement('td'); if (x != null) e.append(x); tr.appendChild(e); return e; };
        td(PP.KOMPONEN[k].label); td(name); td(String(uniq[k][name]));
        const badge = document.createElement('span');
        if (!opts.length) {
          td('—'); badge.className = 'badge b-warn'; badge.textContent = 'Senarai SPPB belum direkod';
        } else {
          const sel = document.createElement('select');
          sel.dataset.src = name;
          opt(sel, '', '— pilih —', '');
          opts.forEach((o) => opt(sel, o, o, m && m.option ? m.option : ''));
          sel.onchange = () => { badge.className = 'badge b-ok'; badge.textContent = 'Manual (tekan Simpan peta)'; };
          td(sel);
          if (m && m.option) { const strong = m.reason === 'tepat' || m.score >= 0.9; badge.className = 'badge ' + (strong ? 'b-ok' : 'b-warn'); badge.textContent = m.reason === 'tepat' ? 'Tepat' : strong ? 'Padan' : 'Anggaran — sahkan'; }
          else { badge.className = 'badge b-err'; badge.textContent = m ? m.reason : 'Tiada'; }
        }
        td(badge);
        t.appendChild(tr);
      });
    });
    box.appendChild(t);
    const b = document.createElement('div'); b.className = 'row';
    const btn = document.createElement('button'); btn.className = 'btn'; btn.textContent = '➕ Tambah pilihan di atas ke peta manual';
    btn.onclick = () => {
      const cur = PP.parseMapping($('mapping').value);
      const lines = $('mapping').value.split(/\r?\n/).filter((l) => l.trim());
      t.querySelectorAll('select').forEach((sel) => {
        if (!sel.value) return;
        const k = PP.norm(sel.dataset.src);
        if (PP.norm(sel.value) === k) return;
        if (cur[k]) { const i = lines.findIndex((l) => PP.norm(l.split(/=>|=/)[0]) === k); if (i >= 0) lines.splice(i, 1); }
        lines.push(sel.dataset.src + ' = ' + sel.value);
      });
      $('mapping').value = lines.join('\n');
      status('mapStatus', 'Ditambah — tekan Simpan peta.', true);
    };
    b.appendChild(btn); box.appendChild(b);
  }

  $('btnSaveMap').onclick = async () => { await store.set({ pp_mapping: $('mapping').value }); status('mapStatus', '✓ Disimpan', true); renderMatches(); };

  // ------------------------------------------------------------------
  // Tetapan
  // ------------------------------------------------------------------
  async function loadSettings() {
    const d = await store.get(['pp_settings', 'pp_defaults', 'pp_mapping']);
    const s = Object.assign({}, PP.DEFAULT_SETTINGS, d.pp_settings || {});
    $('setOverwrite').checked = !!s.overwrite;
    $('setStop').checked = !!s.stopOnError;
    if (!Array.from($('setDelay').options).some((o) => o.value === String(s.stepDelay))) { const o = document.createElement('option'); o.value = String(s.stepDelay); o.textContent = s.stepDelay; $('setDelay').appendChild(o); }
    $('setDelay').value = String(s.stepDelay);
    defaults = Object.assign(JSON.parse(JSON.stringify(PP.DEFAULTS_TEMPLATE)), d.pp_defaults || {});
    $('mapping').value = d.pp_mapping || '';
  }
  $('btnSaveSet').onclick = async () => {
    const d = await store.get(['pp_settings']);
    const s = Object.assign({}, PP.DEFAULT_SETTINGS, d.pp_settings || {}, {
      overwrite: $('setOverwrite').checked, stopOnError: $('setStop').checked, stepDelay: parseInt($('setDelay').value, 10)
    });
    await store.set({ pp_settings: s });
    status('setStatus', '✓ Disimpan', true);
  };

  chrome.storage.onChanged.addListener((ch) => { if (ch.pp_options) { readDefForm(); renderMatches().then(renderDefForm); } });

  (async () => {
    await loadSettings();
    await renderMatches();
    renderDefTabs(); renderDefForm();
    await renderPreview();
  })();
})();
