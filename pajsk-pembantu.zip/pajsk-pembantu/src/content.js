// PAJSK Pembantu — content script untuk moeissppb.moe.gov.my
(function () {
  'use strict';
  if (window.__pajskPembantuContent) return;
  window.__pajskPembantuContent = true;

  const PP = globalThis.PP;
  const { KOMPONEN, KOMPONEN_KEYS, norm, normIC } = PP;

  // ======================================================================
  // Storan
  // ======================================================================
  // Jika extension dikemas kini / dimuat semula (⟳) semasa halaman ini terbuka, skrip lama
  // terputus daripada Chrome ("Extension context invalidated"). Kesan & berhenti dengan senyap.
  let dead = false;
  function alive() {
    if (dead) return false;
    try { if (chrome.runtime && chrome.runtime.id) return true; } catch (e) { /* terputus */ }
    onDead();
    return false;
  }
  function onDead() {
    if (dead) return;
    dead = true;
    try { clearInterval(routeTimer); } catch (e) {}
    const h = document.getElementById('pajsk-pembantu-host');
    if (h) h.remove();
    const n = document.createElement('div');
    n.textContent = 'PAJSK Pembantu telah dikemas kini atau dimuat semula. Tekan F5 untuk menyambung.';
    n.style.cssText = 'position:fixed;right:18px;bottom:18px;z-index:2147483000;max-width:320px;background:#fffbeb;color:#78350f;border:1px solid #fcd34d;border-radius:12px;padding:10px 14px;font:600 13px/1.4 system-ui,sans-serif;box-shadow:0 6px 20px rgba(0,0,0,.2);cursor:pointer';
    n.title = 'Klik untuk muat semula';
    n.onclick = () => location.reload();
    document.documentElement.appendChild(n);
  }
  function send(msg, cb) {
    if (!alive()) { if (cb) cb(null); return; }
    try { chrome.runtime.sendMessage(msg, (r) => { void chrome.runtime.lastError; if (cb) cb(r); }); } catch (e) { onDead(); if (cb) cb(null); }
  }
  const store = {
    get: (keys) => new Promise((res) => {
      if (!alive()) return res({});
      try { chrome.storage.local.get(keys, (r) => { void chrome.runtime.lastError; res(r || {}); }); } catch (e) { onDead(); res({}); }
    }),
    set: (obj) => new Promise((res) => {
      if (!alive()) return res();
      try { chrome.storage.local.set(obj, () => { void chrome.runtime.lastError; res(); }); } catch (e) { onDead(); res(); }
    })
  };

  async function loadAll() {
    const d = await store.get(['pp_students', 'pp_meta', 'pp_defaults', 'pp_mapping', 'pp_settings', 'pp_batch']);
    return {
      students: d.pp_students || {},
      meta: d.pp_meta || null,
      defaults: Object.assign({}, PP.DEFAULTS_TEMPLATE, d.pp_defaults || {}),
      mapping: PP.parseMapping(d.pp_mapping || ''),
      settings: Object.assign({}, PP.DEFAULT_SETTINGS, d.pp_settings || {}),
      batch: d.pp_batch || null
    };
  }

  async function rememberOptions(kind, komp, options) {
    if (!options || !options.length) return;
    const d = await store.get(['pp_options']);
    const o = d.pp_options || {};
    o[kind] = o[kind] || {};
    // jawatan berbeza ikut aktiviti — gabungkan semua yang pernah dilihat
    if (kind === 'jawatan') options = Array.from(new Set([...(o[kind][komp] || []), ...options])).slice(0, 300);
    o[kind][komp] = options;
    await store.set({ pp_options: o });
  }

  // ======================================================================
  // Utiliti
  // ======================================================================
  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
  let STEP = 250;

  async function waitFor(fn, timeout = 8000, every = 100) {
    const t0 = Date.now();
    while (Date.now() - t0 < timeout) {
      let v;
      try { v = fn(); } catch (e) { v = null; }
      if (v) return v;
      await sleep(every);
    }
    return null;
  }

  function txt(el) { return el ? norm(el.textContent) : ''; }
  function visible(el) { return !!(el && el.isConnected && el.getClientRects().length); }

  function realClick(el) {
    if (!el) return;
    const o = { bubbles: true, cancelable: true, view: window };
    el.dispatchEvent(new PointerEvent('pointerdown', o));
    el.dispatchEvent(new MouseEvent('mousedown', o));
    el.dispatchEvent(new PointerEvent('pointerup', o));
    el.dispatchEvent(new MouseEvent('mouseup', o));
    el.click();
  }

  function pageType() {
    const p = location.pathname;
    if (/\/keputusan\/pajsk-skor\/\d+/.test(p)) return 'FORM';
    if (/\/keputusan\/pajsk\/\d+\/?$/.test(p)) return 'LIST';
    if (/\/keputusan\/pajsk/.test(p)) return 'OTHER_PAJSK';
    return 'OTHER';
  }

  // ======================================================================
  // Pemantau rangkaian (dari hook.js)
  // ======================================================================
  const netWaiters = [];
  window.addEventListener('message', (ev) => {
    const d = ev.data;
    if (!d || d.__pajskPembantu !== true || d.type !== 'net') return;
    for (const w of netWaiters.slice()) w(d);
  });
  function waitNet(pred, timeout) {
    return new Promise((resolve) => {
      const fn = (d) => { if (pred(d)) { done(d); } };
      const timer = setTimeout(() => done(null), timeout);
      function done(v) {
        clearTimeout(timer);
        const i = netWaiters.indexOf(fn); if (i >= 0) netWaiters.splice(i, 1);
        resolve(v);
      }
      netWaiters.push(fn);
    });
  }

  // ======================================================================
  // BORANG MURID (pajsk-skor)
  // ======================================================================
  function getForm() {
    const forms = Array.from(document.querySelectorAll('form'));
    return forms.find((f) => f.querySelector('.w-tabs')) || null;
  }

  function headerValue(label) {
    const f = getForm() || document;
    const h = Array.from(f.querySelectorAll('h5')).find((x) => txt(x).startsWith(norm(label)));
    if (!h) return '';
    const v = h.nextElementSibling;
    return v ? v.textContent.trim() : '';
  }

  function readStudent() {
    return { nama: headerValue('Nama'), ic: normIC(headerValue('Id Pengenalan')), kelas: headerValue('Kelas') };
  }

  function tabItems() {
    const f = getForm();
    return f ? Array.from(f.querySelectorAll('.w-tabs__bar-item')) : [];
  }

  function activeContent() {
    const f = getForm();
    return f ? f.querySelector('.w-tabs__content') : null;
  }

  async function switchTab(komp) {
    if (swalEl()) await dismissSwal(500);
    const key = KOMPONEN[komp].tabKey;
    const item = tabItems().find((t) => txt(t).includes(key));
    if (!item) throw new Error('Tab "' + KOMPONEN[komp].label + '" tidak dijumpai');
    if (item.getAttribute('aria-selected') !== 'true') {
      realClick(item);
      await waitFor(() => item.getAttribute('aria-selected') === 'true', 4000);
      await sleep(STEP + 250);
    }
    const c = await waitFor(() => { const x = activeContent(); return x && x.querySelector('.w-select') ? x : null; }, 5000);
    if (!c) throw new Error('Kandungan tab "' + KOMPONEN[komp].label + '" tidak dimuatkan');
    return c;
  }

  function sections(content) {
    const map = {};
    content.querySelectorAll('h5').forEach((h) => {
      const label = txt(h);
      const xs2 = h.closest('.xs2');
      const body = xs2 ? xs2.nextElementSibling : (h.parentElement && h.parentElement.nextElementSibling);
      if (!body) return;
      let key = null;
      if (label.startsWith('AKTIVITI')) key = 'aktiviti';
      else if (label.startsWith('JAWATAN')) key = 'jawatan';
      else if (label.startsWith('PELIBATAN')) key = 'pelibatan';
      else if (label.startsWith('TAHAP PENCAPAIAN') || label.startsWith('PENCAPAIAN')) key = 'pencapaian';
      else if (label.startsWith('KOMITMEN')) key = 'komitmen';
      else if (label.startsWith('KHIDMAT MASYARAKAT')) key = 'khidmatMasyarakat';
      else if (label.startsWith('KHIDMAT')) key = 'khidmat';
      else if (label.startsWith('ANUGERAH')) key = 'anugerah';
      else if (label.includes('NILAM')) key = 'nilam';
      else if (label.startsWith('TIMSS') || label.includes('PISA')) key = 'timss';
      else if (label.startsWith('KEHADIRAN')) key = 'kehadiran';
      else if (label.startsWith('PERKHIDMATAN')) key = 'aktiviti';
      if (key && !map[key]) map[key] = body;
    });
    return map;
  }

  // ---------- Suis "DITAKSIR" ----------
  function switchEl(content) { return content.querySelector('.w-switch'); }
  function switchOn(sw) {
    const i = sw.querySelector('input');
    const a = i && i.getAttribute('aria-checked');
    // Wave UI: kelas w-switch--on ialah penanda yang paling boleh dipercayai
    if (sw.classList.contains('w-switch')) return sw.classList.contains('w-switch--on');
    return a === 'true' || a === '1' || !!(i && i.checked);
  }
  async function setSwitch(content, on) {
    const cur = () => switchEl(activeContent() || content);
    let sw = cur();
    if (!sw) return false;
    if (switchOn(sw) === on) return true;
    const tries = [
      (x) => x.querySelector('input').click(),
      (x) => realClick(x.querySelector('.w-switch__input') || x),
      (x) => realClick(x.querySelector('.w-switch__track, .w-switch__thumb') || x),
      (x) => realClick(x)
    ];
    for (const t of tries) {
      sw = cur();
      if (!sw) return false;
      if (switchOn(sw) === on) return true;
      t(sw);
      await sleep(STEP + 150);
    }
    sw = cur();
    return !!sw && switchOn(sw) === on;
  }

  // ---------- Checkbox ----------
  function cbChecked(input) {
    const w = input.closest('.w-checkbox');
    if (w && (w.classList.contains('w-checkbox--checked') || w.classList.contains('w-checkbox--unchecked'))) return w.classList.contains('w-checkbox--checked');
    const a = input.getAttribute('aria-checked');
    if (a === 'true' || a === 'false') return a === 'true';
    return !!input.checked;
  }
  async function setCb(input, on) {
    if (cbChecked(input) === on) return true;
    input.click();
    await sleep(Math.max(60, STEP / 3));
    if (cbChecked(input) !== on) {
      const w = input.closest('.w-checkbox');
      realClick((w && w.querySelector('.w-checkbox__input')) || input);
      await sleep(Math.max(60, STEP / 3));
    }
    return cbChecked(input) === on;
  }

  function cbLabel(input) {
    const id = input.id;
    let l = id ? document.querySelector('label[for="' + CSS.escape(id) + '"]') : null;
    if (l && l.textContent.trim()) return norm(l.textContent);
    const td = input.closest('td');
    if (td) return norm(td.textContent);
    const ul = input.closest('ul');
    return ul ? norm(ul.textContent) : '';
  }

  function listItems(body) {
    return Array.from(body.querySelectorAll('input[type=checkbox]')).map((i) => ({ input: i, label: cbLabel(i) }));
  }

  // grid: { rowLabel -> { colLabel -> input } }
  function grid(body) {
    const table = body.querySelector('table');
    if (!table) return null;
    const rows = Array.from(table.querySelectorAll('tr'));
    const head = rows.find((r) => r.querySelector('th'));
    const cols = head ? Array.from(head.querySelectorAll('th')).map(txt) : [];
    const g = {};
    rows.forEach((r) => {
      const tds = Array.from(r.querySelectorAll('td'));
      if (tds.length < 2) return;
      const rl = txt(tds[0]);
      g[rl] = {};
      tds.forEach((td, j) => {
        const inp = td.querySelector('input[type=checkbox]');
        if (inp && cols[j]) g[rl][cols[j]] = inp;
      });
    });
    return g;
  }

  function allInputs(body) { return Array.from(body.querySelectorAll('input[type=checkbox]')); }
  function anyChecked(body) { return allInputs(body).some(cbChecked); }
  async function clearAll(body) { for (const i of allInputs(body)) if (cbChecked(i)) await setCb(i, false); }

  async function fillGrid(body, items, label, log) {
    const g = grid(body);
    if (!g) { log.push('⚠ ' + label + ': jadual tidak dijumpai'); return false; }
    let ok = true;
    for (const it of items) {
      const rowKey = Object.keys(g).find((k) => k === norm(it.peringkat)) || Object.keys(g).find((k) => k.startsWith(norm(it.peringkat).split(' ')[0]));
      const row = rowKey ? g[rowKey] : null;
      const colKey = row ? Object.keys(row).find((c) => (typeof it.col === 'number' ? c.endsWith(' ' + it.col) : c === norm(it.col))) : null;
      if (!row || !colKey) { log.push('⚠ ' + label + ': ' + it.peringkat + ' / ' + it.col + ' tiada dalam borang'); ok = false; continue; }
      if (!(await setCb(row[colKey], true))) { log.push('⚠ ' + label + ': gagal tanda ' + rowKey + ' / ' + colKey); ok = false; }
    }
    return ok;
  }

  async function fillList(body, wanted, label, max, log) {
    const items = listItems(body);
    const picked = [];
    for (const w of wanted) {
      let it = null;
      const s = String(w).trim();
      if (/^\d+$/.test(s) && label !== 'Kehadiran') {
        it = items[parseInt(s, 10) - 1];
      } else if (label === 'Kehadiran') {
        it = items.find((x) => x.label === s);
      } else {
        const m = PP.bestMatch(s, items.map((x) => x.label), null, true);
        if (m.option) it = items.find((x) => x.label === m.option);
        if (!it) it = items.find((x) => x.label.includes(norm(s)));
      }
      if (!it) { log.push('⚠ ' + label + ': "' + s + '" tiada dalam pilihan'); continue; }
      if (!picked.includes(it)) picked.push(it);
    }
    if (max && picked.length > max) { log.push('⚠ ' + label + ': maksimum ' + max + ' pilihan — hanya ' + max + ' pertama diambil'); picked.length = max; }
    for (const it of picked) if (!(await setCb(it.input, true))) log.push('⚠ ' + label + ': gagal tanda "' + it.label + '"');
    return picked.length;
  }

  // ---------- Dropdown (w-select) ----------
  function selectParts(body) {
    const sel = body.querySelector('.w-select');
    if (!sel) return null;
    const wrap = sel.querySelector('.w-select__selection-wrap') || sel;
    const input = sel.querySelector('input.w-select__selection');
    const selEl = sel.querySelector('.w-select__selection');
    const menuId = wrap.getAttribute('aria-owns');
    const disabled = sel.classList.contains('w-select--disabled') || sel.classList.contains('w-select--readonly') && false;
    return { sel, wrap, input, selEl, menuId, disabled };
  }

  function selectValue(parts) {
    if (!parts) return '';
    let v = parts.input ? parts.input.value : '';
    if (!v) {
      const s = parts.sel.querySelector('.w-select__selection-slot, .w-select__selection');
      v = s && s.tagName !== 'INPUT' ? s.textContent : v;
      if (s && v && (s.getAttribute('placeholder') || '').trim() === v.trim()) v = '';
    }
    return (v || '').trim();
  }

  // Kosongkan dropdown (tiada butang "x" dalam SPPB) — melalui hook.js dalam konteks halaman
  const CLEAR = '__CLEAR__';
  function isClear(v) { return String(v == null ? '' : v).trim() === CLEAR; }
  async function clearSelect(getBody) {
    const parts = selectParts(getBody() || document.createElement('div'));
    if (!parts) return { ok: false, msg: 'dropdown tidak dijumpai' };
    if (!selectValue(parts)) return { ok: true, already: true };
    const id = (parts.selEl && parts.selEl.id) || (parts.input && parts.input.id);
    if (!id) return { ok: false, msg: 'id dropdown tidak dijumpai' };
    const reqId = Math.random().toString(36).slice(2);
    const res = await new Promise((resolve) => {
      const t = setTimeout(() => { window.removeEventListener('message', on); resolve(null); }, 3000);
      function on(ev) {
        const d = ev.data;
        if (d && d.__pajskPembantu === true && d.type === 'clearSelectResult' && d.reqId === reqId) { clearTimeout(t); window.removeEventListener('message', on); resolve(d); }
      }
      window.addEventListener('message', on);
      window.postMessage({ __pajskPembantu: true, type: 'clearSelect', id, reqId }, '*');
    });
    if (!res || !res.ok) return { ok: false, msg: 'tidak dapat dikosongkan (' + (res ? res.how : 'tiada jawapan') + ') — kosongkan sendiri' };
    await waitFor(() => { const p2 = selectParts(getBody()); return p2 && !selectValue(p2); }, 2000);
    return { ok: true };
  }

  function menuEl(parts) {
    if (parts.menuId) { const m = document.getElementById(parts.menuId); if (m) return m; }
    const menus = Array.from(document.querySelectorAll('.w-select__menu, .w-menu'));
    return menus.find(visible) || null;
  }

  function menuOptions(menu) {
    if (!menu) return [];
    let els = Array.from(menu.querySelectorAll('[role="option"]'));
    if (!els.length) els = Array.from(menu.querySelectorAll('.w-list__item-label'));
    if (!els.length) els = Array.from(menu.querySelectorAll('li'));
    return els.map((el) => ({ el, label: el.textContent.replace(/\s+/g, ' ').trim() })).filter((o) => o.label);
  }

  async function openMenu(parts) {
    const tries = [() => realClick(parts.wrap), () => parts.input && realClick(parts.input), () => parts.wrap.dispatchEvent(new KeyboardEvent('keydown', { key: 'Enter', keyCode: 13, bubbles: true }))];
    for (const t of tries) {
      t();
      const m = await waitFor(() => { const x = menuEl(parts); return x && menuOptions(x).length ? x : null; }, 2500);
      if (m) { await sleep(150); return m; }
    }
    return null;
  }

  async function closeMenu(parts) {
    const m = menuEl(parts);
    if (!visible(m)) return;
    document.dispatchEvent(new KeyboardEvent('keydown', { key: 'Escape', keyCode: 27, bubbles: true }));
    await sleep(150);
    if (visible(menuEl(parts))) { realClick(parts.wrap); await sleep(150); }
  }

  async function chooseSelect(getBody, wanted, ctx, kind, komp) {
    const parts = selectParts(getBody());
    // elemen mungkin dilukis semula oleh Vue selepas memilih — sentiasa cari semula
    const curVal = () => { const b = getBody(); const pp = b && selectParts(b); return pp ? selectValue(pp) : ''; };
    if (!parts) return { ok: false, msg: 'dropdown tidak dijumpai' };
    const cur = selectValue(parts);
    // Senarai (terutama Jawatan) dimuatkan dari pelayan selepas aktiviti dipilih — tunggu & cuba semula.
    const PLACEHOLDER = /^(tiada|no data|no item|tidak ada|loading|memuat|sila tunggu)/i;
    const deadline = Date.now() + (kind === 'jawatan' ? 12000 : 7000);
    let menu = null, opts = [], m = null, tries = 0;
    for (;;) {
      tries++;
      const p0 = selectParts(getBody()) || parts;
      menu = await openMenu(p0);
      opts = menu ? menuOptions(menu).filter((o) => !PLACEHOLDER.test(o.label)) : [];
      if (opts.length) {
        rememberOptions(kind, komp, opts.map((o) => o.label));
        // Jawatan boleh ada pilihan sandaran: "AHLI AKTIF; AHLI BIASA" → yang pertama wujud
        const alts = kind === 'jawatan' ? String(wanted).split(';').map((x) => x.trim()).filter(Boolean) : [wanted];
        for (const w of alts) { m = PP.matchFor(komp, kind, w, opts.map((o) => o.label), ctx.mapping, kind === 'jawatan', kind === 'aktiviti' ? ctx.pkScore : null); if (m.option) break; }
        if (m.option) break;
        if (komp === 'EKSTRA' && kind === 'aktiviti') { await closeMenu(p0); break; } // padanan tegas: tiada guna cuba semula
      }
      if (menu) await closeMenu(p0);
      if (Date.now() > deadline) break;
      await sleep(900);
    }
    if (!menu) return { ok: false, msg: 'senarai pilihan tidak terbuka' };
    if (!opts.length) return { ok: false, msg: 'senarai pilihan kosong selepas ' + tries + ' cubaan (SPPB lambat? cuba tetapan kelajuan lebih perlahan)', current: cur };
    if (!m || !m.option) {
      return { ok: false, msg: '"' + wanted + '" ' + (m ? m.reason : 'tiada padanan') + (m && m.candidates && m.candidates.length ? ' — calon: ' + m.candidates.join(' | ') : ''), current: cur };
    }
    if (norm(cur) === norm(m.option)) { await closeMenu(parts); return { ok: true, chosen: m.option, same: true, how: m.reason }; }
    const o = opts.find((x) => x.label === m.option);
    realClick(o.el);
    const done = await waitFor(() => norm(curVal()) === norm(m.option), 3000);
    if (!done) {
      // cuba klik elemen li induk
      const li = o.el.closest('li, .w-list__item');
      if (li && li !== o.el && li.isConnected) { realClick(li); await waitFor(() => norm(curVal()) === norm(m.option), 2000); }
    }
    const p2 = selectParts(getBody()) || parts;
    await closeMenu(p2);
    const okNow = norm(curVal()) === norm(m.option);
    return { ok: okNow, chosen: m.option, how: m.reason, msg: okNow ? '' : 'pilihan tidak berubah' };
  }

  function isEkstraKomp(k) { return !!(KOMPONEN[k] && KOMPONEN[k].ekstra); }

  // Skor bahagian yang dikira SPPB ("= N" di bawah setiap bahagian)
  function sectionScore(body) {
    if (!body) return null;
    const m = (body.textContent || '').match(/=\s*(-?\d+(?:\.\d+)?)/g);
    if (!m) return null;
    return parseFloat(m[m.length - 1].replace(/=\s*/, ''));
  }

  // calon dalam jadual: baris (peringkat) × lajur (label tajuk)
  function gridCands(body, rows, cols) {
    const g = grid(body);
    if (!g) return [];
    const out = [];
    for (const r of rows) {
      const rk = Object.keys(g).find((k) => k === norm(r)) || Object.keys(g).find((k) => k.startsWith(norm(r).split(' ')[0]));
      if (!rk) continue;
      for (const c of cols) {
        const ck = Object.keys(g[rk]).find((x) => x === norm(c));
        if (ck) out.push({ input: g[rk][ck], desc: rk + ' / ' + ck });
      }
    }
    return out;
  }

  // Tanda calon satu demi satu sehingga skor SPPB sama dengan sasaran (slip). Jika tiada yang sama, kekalkan calon pertama.
  async function calibrate(getBody, candsFn, target) {
    const n = candsFn(getBody()).length;
    if (!n) return { ok: false, desc: 'tiada pilihan sepadan', sc: sectionScore(getBody()) };
    for (let i = 0; i < n; i++) {
      const c = candsFn(getBody())[i];
      if (!c) break;
      await setCb(c.input, true);
      await sleep(Math.max(150, STEP));
      const sc = sectionScore(getBody());
      if (target == null || sc === target) return { ok: true, desc: c.desc, sc };
      const c2 = candsFn(getBody())[i];
      if (c2) await setCb(c2.input, false);
      await sleep(60);
    }
    const c0 = candsFn(getBody())[0];
    await setCb(c0.input, true);
    await sleep(Math.max(150, STEP));
    return { ok: false, desc: c0.desc, sc: sectionScore(getBody()) };
  }

  // ---------- Isi satu komponen ----------
  async function fillKomponen(komp, eff, ctx, log) {
    const L = KOMPONEN[komp].label;
    const content = await switchTab(komp);
    let sec = sections(content);
    const slip = eff.__slip || null; // data daripada Slip Infomurid: sumber sahih → sentiasa diselaraskan
    const overwrite = ctx.settings.overwrite || !!slip;
    ctx.pkScore = isEkstraKomp(komp) && slip ? slip.perkhidmatanSkor : null;

    const actParts = sec.aktiviti && selectParts(sec.aktiviti);
    const curAct = selectValue(actParts);
    const hasWanted = !PP.isBlank(eff.aktiviti);
    const isEkstra = !!KOMPONEN[komp].ekstra;
    const hasEkstraOther = isEkstra && PP.EKSTRA_FIELDS.some((f) => !PP.isBlank(eff[f]));

    if (!hasWanted && !curAct && !hasEkstraOther) {
      // Tiada aktiviti untuk komponen ini: matikan suis DITAKSIR dan simpan (jika gagal, teruskan sahaja)
      const sw = switchEl(content);
      if (sw && switchOn(sw) && ctx.hasData) {
        if (await setSwitch(content, false)) { log.push('• ' + L + ': tiada aktiviti — suis DITAKSIR dimatikan'); return { filled: false, switched: true, optional: true }; }
        log.push('⚠ ' + L + ': tiada aktiviti — suis DITAKSIR tidak dapat dimatikan (dibiarkan)');
        return { filled: false, empty: true };
      }
      log.push('• ' + L + ': tiada aktiviti — suis DITAKSIR sudah mati, dilangkau');
      return { filled: false, empty: true };
    }

    if (!(await setSwitch(content, true))) log.push('⚠ ' + L + ': suis DITAKSIR tidak dapat dihidupkan');
    await sleep(STEP);
    sec = sections(activeContent());

    if (hasWanted && isClear(eff.aktiviti)) {
      if (curAct) {
        const r = await clearSelect(() => sections(activeContent()).aktiviti);
        log.push(r.ok ? '✓ ' + L + ': Perkhidmatan dikosongkan' : '⚠ ' + L + ': Perkhidmatan ' + r.msg);
        await sleep(STEP);
      }
    } else if (hasWanted) {
      if (curAct && norm(curAct) !== norm(eff.aktiviti) && !overwrite) {
        const r0 = PP.bestMatch(eff.aktiviti, [curAct], ctx.mapping);
        if (!r0.option) { log.push('• ' + L + ': aktiviti sedia ada "' + curAct + '" dikekalkan (tetapan: jangan ganti)'); }
      } else if (!curAct || overwrite) {
        const r = await chooseSelect(() => sections(activeContent()).aktiviti, eff.aktiviti, ctx, 'aktiviti', komp);
        if (!r.ok) { log.push('✖ ' + L + ': ' + (KOMPONEN[komp].ekstra ? 'perkhidmatan ' : 'aktiviti ') + r.msg); return { filled: false, error: true }; }
        log.push('✓ ' + L + ': ' + r.chosen + (r.how === 'anggaran' ? ' (padanan anggaran untuk "' + eff.aktiviti + '")' : /^ikut skor/.test(r.how || '') ? ' (' + r.how + ' untuk "' + eff.aktiviti + '")' : ''));
        await sleep(STEP + 400);
        sec = sections(activeContent());
      }
    }

    if (isEkstra) { await fillEkstra(eff, ctx, log); return { filled: true }; }
    let jawErr = false;

    // Jawatan
    if (!PP.isBlank(eff.jawatan) && sec.jawatan) {
      const jp = selectParts(sec.jawatan);
      const curJ = selectValue(jp);
      const wantJ = slip && slip.jawatan ? PP.slipJawatanAlts(eff.jawatan).concat(String(eff.jawatan).split(';').slice(1)).join('; ') : eff.jawatan;
      if (!curJ || overwrite) {
        const r = await chooseSelect(() => sections(activeContent()).jawatan, wantJ, ctx, 'jawatan', komp);
        if (!r.ok) { log.push('✖ ' + L + ': jawatan ' + r.msg + (slip ? ' — petakan nama jawatan slip di Tetapan bahagian 3 (Peta manual)' : '')); jawErr = true; }
        else log.push('  jawatan: ' + r.chosen);
        await sleep(STEP);
        sec = sections(activeContent());
      }
      if (slip && slip.jawatanSkor != null) {
        const sc = sectionScore(sections(activeContent()).jawatan);
        if (sc != null && sc !== slip.jawatanSkor) log.push('⚠ ' + L + ': skor jawatan SPPB ' + sc + ' ≠ slip ' + slip.jawatanSkor + ' ("' + slip.jawatan + '")');
      }
    }

    // Data slip: Pelibatan / Pencapaian / Kehadiran diselaraskan mengikut SKOR slip (dibandingkan dengan "= N" SPPB)
    const doneSlip = [];
    if (slip) {
      const gb = (k) => () => sections(activeContent())[k];
      // Pelibatan: baris = peringkat; cuba Pelibatan 1, 2, 3 sehingga skor sama
      const bP = gb('pelibatan')();
      if (bP) {
        await clearAll(bP);
        if (slip.pelibatan) {
          const r = await calibrate(gb('pelibatan'), (b) => gridCands(b, [slip.pelibatan], ['PELIBATAN 1', 'PELIBATAN 2', 'PELIBATAN 3']), slip.pelibatanSkor);
          doneSlip.push('Pelibatan ' + (r.desc || '?') + ' (=' + r.sc + (r.ok ? '' : ' ≠ slip ' + slip.pelibatanSkor) + ')');
          if (!r.ok) log.push('⚠ ' + L + ': skor Pelibatan tidak sama dengan slip — semak');
        }
      }
      // Pencapaian: lajur = kedudukan; slip tiada peringkat → cuba setiap peringkat sehingga skor sama
      const bC = gb('pencapaian')();
      if (bC) {
        await clearAll(bC);
        if (slip.pencapaian) {
          const rowsOrder = ['SEKOLAH', 'ZON/DAERAH', 'NEGERI', 'BAHAGIAN (SABAH/SARAWAK)', 'KEBANGSAAN', 'ANTARABANGSA'];
          const r = await calibrate(gb('pencapaian'), (b) => gridCands(b, rowsOrder, [slip.pencapaian]), slip.pencapaianSkor);
          doneSlip.push('Pencapaian ' + (r.desc || '?') + ' (=' + r.sc + (r.ok ? '' : ' ≠ slip ' + slip.pencapaianSkor) + ')');
          if (!r.ok) log.push('⚠ ' + L + ': skor Pencapaian tidak sama dengan slip — semak');
        }
      }
      // Kehadiran: slip memberi skor (cth. 50); cari bilangan kehadiran yang memberi skor itu
      const bK = gb('kehadiran')();
      if (bK && slip.kehadiranSkor != null) {
        await clearAll(bK);
        const target = slip.kehadiranSkor;
        const labels = target === 0 ? ['0'] : ['12', '11', '10', '9', '8', '7', '6', '5', '4', '3', '2', '1'];
        const r = await calibrate(gb('kehadiran'), (b) => listItems(b).filter((x) => labels.includes(x.label)).sort((a, c) => labels.indexOf(a.label) - labels.indexOf(c.label)).map((x) => ({ input: x.input, desc: x.label })), target);
        doneSlip.push('Kehadiran ' + (r.desc || '?') + ' (=' + r.sc + (r.ok ? '' : ' ≠ slip ' + target) + ')');
        if (!r.ok) log.push('⚠ ' + L + ': skor Kehadiran tidak sama dengan slip — semak');
      }
    }

    const groups = [
      ['pelibatan', 'Pelibatan', (b, v) => fillGrid(b, PP.parsePelibatan(v), 'Pelibatan', log)],
      ['pencapaian', 'Pencapaian', (b, v) => fillGrid(b, PP.parsePencapaian(v).slice(0, 1), 'Pencapaian', log)],
      ['komitmen', 'Komitmen', (b, v) => fillList(b, PP.splitList(v), 'Komitmen', 4, log)],
      ['khidmat', 'Khidmat', (b, v) => fillList(b, PP.splitList(v).slice(0, 1), 'Khidmat', 1, log)],
      ['kehadiran', 'Kehadiran', (b, v) => { const n = PP.parseKehadiran(v); return n == null ? 0 : fillList(b, [String(n)], 'Kehadiran', 1, log); }]
    ];
    const done = doneSlip;
    for (const [key, label, fn] of groups) {
      if (slip && (key === 'pelibatan' || key === 'pencapaian' || key === 'kehadiran')) continue;
      if (PP.isBlank(eff[key])) continue;
      const body = sections(activeContent())[key];
      if (!body) { log.push('⚠ ' + L + ': bahagian ' + label + ' tidak dijumpai'); continue; }
      if (anyChecked(body)) {
        if (!overwrite) continue;
        await clearAll(body);
      }
      await fn(body, eff[key]);
      done.push(label + ' ' + eff[key]);
    }
    if (done.length) log.push('  ' + done.join(' · '));
    return { filled: true, error: jawErr };
  }

  // ---------- Bahagian tambahan tab Ekstra Kurikulum ----------
  function tableRows(body) {
    return Array.from(body.querySelectorAll('tr')).map((tr) => {
      const tds = Array.from(tr.querySelectorAll('td'));
      const cbs = Array.from(tr.querySelectorAll('input[type=checkbox]'));
      return { label: tds.length ? norm(tds[0].textContent).replace(/\s*\|\s*\d+\s*$/, '') : '', cbs };
    }).filter((r) => r.label && r.cbs.length);
  }

  function pickRow(rows, wanted) {
    const m = PP.bestMatch(wanted, rows.map((r) => r.label), null, true);
    if (m.option) return rows.find((r) => r.label === m.option);
    return rows.find((r) => r.label.includes(norm(wanted))) || null;
  }

  async function fillEkstra(eff, ctx, log) {
    const L = 'Ekstra';
    const overwrite = ctx.settings.overwrite;
    const done = [];
    const body = (k) => sections(activeContent())[k];
    const prep = async (k, label) => {
      const b = body(k);
      if (!b) { log.push('⚠ ' + L + ': bahagian ' + label + ' tidak dijumpai'); return null; }
      if (isClear(eff[k])) {
        if (anyChecked(b)) { await clearAll(b); done.push(label + ': dikosongkan'); }
        return null; // tiada apa untuk ditanda
      }
      if (anyChecked(b)) { if (!overwrite) return null; await clearAll(b); }
      return body(k);
    };

    if (!PP.isBlank(eff.anugerah)) {
      const b = await prep('anugerah', 'Anugerah Khas');
      if (b) {
        const a = PP.parseAnugerah(eff.anugerah);
        const row = a && pickRow(tableRows(b), a.label);
        if (!row) log.push('⚠ ' + L + ': anugerah "' + eff.anugerah + '" tiada dalam senarai');
        else {
          const i = a.tahap ? PP.ARP_TAHAP.indexOf(a.tahap) : 0;
          const cb = row.cbs[Math.max(0, Math.min(i, row.cbs.length - 1))];
          if (await setCb(cb, true)) done.push('Anugerah: ' + row.label + (a.tahap ? ' (' + a.tahap + ')' : ''));
        }
      }
    }

    if (!PP.isBlank(eff.khidmatMasyarakat)) {
      const b = await prep('khidmatMasyarakat', 'Khidmat Masyarakat');
      if (b) {
        let left = 5;
        const parts = [];
        for (const it of PP.parseKhidmatMasyarakat(eff.khidmatMasyarakat)) {
          const row = pickRow(tableRows(body('khidmatMasyarakat')), it.label);
          if (!row) { log.push('⚠ ' + L + ': khidmat masyarakat "' + it.label + '" tiada dalam senarai'); continue; }
          const n = Math.min(it.n, left, row.cbs.length);
          for (let k = 0; k < n; k++) await setCb(tableRows(body('khidmatMasyarakat')).find((r) => r.label === row.label).cbs[k], true);
          left -= n;
          parts.push(row.label.replace(/^AKTIVITI\s+/, '') + ' ×' + n);
          if (left <= 0) { if (it !== undefined) log.push('  (Khidmat Masyarakat: maksimum 5 aktiviti dicapai)'); break; }
        }
        if (parts.length) done.push('Khidmat Masyarakat: ' + parts.join(', '));
      }
    }

    if (!PP.isBlank(eff.nilam)) {
      const b = await prep('nilam', 'Program NILAM');
      const n = PP.parseNilam(eff.nilam);
      if (b && n) {
        const cbs = allInputs(b);
        const order = (b.textContent.match(/([1-5])\s*BINTANG/gi) || []).map((x) => parseInt(x, 10));
        let i = order.length === cbs.length ? order.indexOf(n) : 5 - n;
        if (i < 0 || i >= cbs.length) log.push('⚠ ' + L + ': NILAM ' + n + ' bintang tidak dijumpai');
        else if (await setCb(cbs[i], true)) done.push('NILAM ' + n + ' bintang');
      }
    }

    if (!PP.isBlank(eff.timss)) {
      const b = body('timss');
      const cur = b && selectValue(selectParts(b));
      if (!b) log.push('⚠ ' + L + ': bahagian TIMSS dan PISA tidak dijumpai');
      else if (isClear(eff.timss)) {
        if (cur) { const r = await clearSelect(() => body('timss')); if (r.ok) done.push('TIMSS/PISA: dikosongkan'); else log.push('⚠ ' + L + ': TIMSS/PISA ' + r.msg); }
      } else if (!cur || overwrite) {
        const r = await chooseSelect(() => body('timss'), eff.timss, ctx, 'timss', 'EKSTRA');
        if (r.ok) done.push('TIMSS/PISA: ' + r.chosen); else log.push('⚠ ' + L + ': TIMSS/PISA ' + r.msg);
      }
    }
    if (done.length) log.push('  ' + done.join(' · '));
  }

  function findButton(label) {
    const f = getForm() || document;
    return Array.from(f.querySelectorAll('button')).find((b) => txt(b) === norm(label)) || null;
  }

  function formErrors() {
    const f = getForm();
    if (!f) return [];
    return Array.from(f.querySelectorAll('.w-form-el__error')).map((e) => e.textContent.trim()).filter(Boolean);
  }

  // Dialog SweetAlert SPPB ("Berjaya! Rekod telah berjaya ditambah" + butang OK)
  function swalEl() {
    return Array.from(document.querySelectorAll('.swal2-popup, .swal-modal, .sweet-alert')).find(visible) || null;
  }
  async function dismissSwal(timeout) {
    const pop = await waitFor(swalEl, timeout, 100);
    if (!pop) return null;
    const title = ((pop.querySelector('.swal2-title, .swal-title, h2') || {}).textContent || '').trim();
    const text = ((pop.querySelector('.swal2-html-container, .swal2-content, .swal-text, p') || {}).textContent || '').trim();
    const btn = pop.querySelector('.swal2-confirm, .swal-button--confirm, button.confirm') || pop.querySelector('button');
    if (btn) realClick(btn);
    await waitFor(() => !swalEl(), 4000);
    await sleep(250);
    return { title, text, all: title + ' ' + text };
  }

  async function saveCurrent() {
    if (swalEl()) await dismissSwal(500);
    const btn = findButton('Simpan');
    if (!btn) return { ok: false, msg: 'Butang Simpan tidak dijumpai' };
    if (btn.disabled) return { ok: false, msg: 'Butang Simpan tidak aktif' };
    const errsBefore = formErrors().join('|');
    const p = waitNet((d) => d.method !== 'GET' && /pajsk/i.test(d.url), 20000);
    realClick(btn);
    // Tamat apabila: respons pelayan, dialog SweetAlert, atau ralat pengesahan borang baharu (tiada permintaan dihantar)
    const newErrs = () => { const e = formErrors(); return e.length && e.join('|') !== errsBefore ? 'invalid' : null; };
    const r = await Promise.race([
      p,
      waitFor(swalEl, 20000).then(() => sleep(400)).then(() => 'swal'),
      sleep(1500).then(() => waitFor(newErrs, 18500)).then((x) => (x ? sleep(2500).then(() => 'invalid') : null))
    ]);
    const net = r && typeof r === 'object' ? r : null;
    const sw = await dismissSwal(net || r === 'swal' ? 5000 : 1200);
    await sleep(400);
    const errs = formErrors();
    if (sw) {
      // Dialog SPPB lebih dipercayai daripada teks ralat lama pada borang
      if (/ralat|gagal|error|tidak berjaya|invalid/i.test(sw.all)) return { ok: false, msg: 'SPPB: ' + sw.all };
      if (/berjaya|success|disimpan|ditambah|dikemaskini|dikemas kini/i.test(sw.all)) return { ok: true, msg: sw.all };
    }
    if (r === 'invalid' && !net) return { ok: false, invalid: true, msg: 'Borang tidak lengkap: ' + (errs.join('; ') || 'medan wajib kosong') };
    if (!net && !sw && errs.length) return { ok: false, invalid: true, msg: 'Ralat borang: ' + errs.join('; ') };
    if (net) {
      const r = net;
      if (r.status >= 200 && r.status < 400) {
        if (errs.length && errs.join('|') !== errsBefore) return { ok: false, msg: 'Ralat borang: ' + errs.join('; ') };
        // Inertia mungkin pulang 200 dengan props.errors
        try {
          const j = JSON.parse(r.body);
          const e = j && j.props && j.props.errors;
          if (e && Object.keys(e).length) return { ok: false, msg: 'Ralat: ' + Object.values(e).flat().join('; ') };
        } catch (e) {}
        return { ok: true };
      }
      let msg = 'HTTP ' + r.status;
      try { const j = JSON.parse(r.body); if (j.message) msg += ' — ' + j.message; if (j.errors) msg += ': ' + Object.values(j.errors).flat().join('; '); } catch (e) {}
      return { ok: false, msg };
    }
    if (errs.length) return { ok: false, msg: 'Ralat borang: ' + errs.join('; ') };
    return { ok: false, unknown: true, msg: 'Tiada maklum balas pelayan dalam 20 saat' };
  }

  // ======================================================================
  // SENARAI MURID (pajsk/{id})
  // ======================================================================
  function listTable() {
    return Array.from(document.querySelectorAll('table.w-table')).find((t) => /ID PENGENALAN/.test(txt(t.querySelector('tr')))) || null;
  }

  function listInfo() {
    const info = {};
    document.querySelectorAll('h5, b, strong, label').forEach((h) => {
      const t = txt(h).replace(/\s*:\s*$/, '');
      if (['SESI PERSEKOLAHAN', 'TAHUN / TINGKATAN', 'KELAS', 'AKTIVITI', 'STATUS', 'BILANGAN MURID'].includes(t)) {
        const v = h.nextElementSibling;
        if (v && !info[t]) info[t] = v.textContent.trim();
      }
    });
    return info;
  }

  function cellAct(td) {
    if (!td) return { aktiviti: '', skor: '' };
    const c = td.cloneNode(true);
    const p = c.querySelector('.skor');
    const skor = p ? p.textContent.trim() : '';
    if (p) p.remove();
    return { aktiviti: c.textContent.replace(/\s+/g, ' ').trim(), skor: skor === '(%)' ? '' : skor };
  }
  function cellTambahan(td) {
    if (!td) return '';
    return Array.from(td.querySelectorAll('li')).map((l) => l.textContent.trim()).filter(Boolean).join('; ');
  }

  function parseList() {
    const t = listTable();
    if (!t) return [];
    return Array.from(t.querySelectorAll('tr.w-table__row, tbody tr')).filter((r) => r.querySelectorAll('td').length >= 10).map((r) => {
      const td = Array.from(r.querySelectorAll('td'));
      const a = r.querySelector('a[href*="pajsk-skor"]');
      const kel = cellAct(td[3]), uni = cellAct(td[5]), suk = cellAct(td[7]);
      return {
        row: r,
        bil: td[0].textContent.trim(),
        nama: (() => { const c = td[1].cloneNode(true); c.querySelectorAll('.pp-mark').forEach((x) => x.remove()); return c.textContent.trim(); })(),
        ic: normIC(td[2].textContent),
        KELAB: kel, KELAB_T: cellTambahan(td[4]),
        UNIFORM: uni, UNIFORM_T: cellTambahan(td[6]),
        SUKAN: suk, SUKAN_T: cellTambahan(td[8]),
        EKSTRA: (() => { const c = td[9].cloneNode(true); const l = c.querySelector('.skor'); const sk = l ? l.textContent.trim() : ''; if (l) l.remove(); return { aktiviti: c.textContent.replace(/\|/g, ' ').replace(/\s+/g, ' ').trim(), skor: sk }; })(),
        gpa: td[10].textContent.trim(), cgpa: td[11].textContent.trim(), gred: td[12].textContent.trim().replace(/^-$/, ''),
        status: td[13].textContent.trim(),
        url: a ? a.href : ''
      };
    });
  }

  function download(name, content, mime) {
    const blob = new Blob(['﻿' + content], { type: mime || 'text/csv;charset=utf-8' });
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = name;
    document.body.appendChild(a);
    a.click();
    setTimeout(() => { URL.revokeObjectURL(a.href); a.remove(); }, 2000);
  }

  function exportList() {
    const rows = parseList();
    if (!rows.length) { ui.log('✖ Jadual senarai murid tidak dijumpai'); return; }
    const info = listInfo();
    const head = ['Bil', 'Nama', 'Id Pengenalan', 'Kelas', 'Kelab & Persatuan', 'Skor Kelab', 'Tambahan Kelab', 'Badan Beruniform', 'Skor Uniform', 'Tambahan Uniform', 'Sukan & Permainan', 'Skor Sukan', 'Tambahan Sukan', 'Ekstra Kurikulum', 'GPA', 'CGPA', 'Gred', 'Status'];
    const out = [head];
    rows.forEach((r) => out.push([r.bil, r.nama, "'" + r.ic, info['KELAS'] || '', r.KELAB.aktiviti, r.KELAB.skor, r.KELAB_T, r.UNIFORM.aktiviti, r.UNIFORM.skor, r.UNIFORM_T, r.SUKAN.aktiviti, r.SUKAN.skor, r.SUKAN_T, [r.EKSTRA.aktiviti, r.EKSTRA.skor].filter(Boolean).join(' | '), r.gpa, r.cgpa, r.gred, r.status]));
    const kelas = (info['TAHUN / TINGKATAN'] || '').replace(/TINGKATAN\s*/i, 'T') + '_' + (info['KELAS'] || 'kelas');
    download('PAJSK_' + kelas.replace(/[^\w-]+/g, '_') + '_' + new Date().toISOString().slice(0, 10) + '.csv', PP.toCSV(out));
    ui.log('✓ Dieksport ' + rows.length + ' murid ke CSV');
  }

  function clearMarks() {
    document.querySelectorAll('.pp-mark').forEach((e) => e.remove());
    document.querySelectorAll('[data-pp-hl]').forEach((r) => { r.style.background = ''; r.removeAttribute('data-pp-hl'); });
  }

  async function checkList() {
    clearMarks();
    const ctx = await loadAll();
    const rows = parseList();
    if (!rows.length) { ui.log('✖ Jadual senarai murid tidak dijumpai'); return; }
    const hasData = Object.keys(ctx.students).length > 0;
    let belum = 0, tidakLengkap = 0, beza = 0, ok = 0;
    const lines = [];
    const seen = new Set();
    rows.forEach((r) => {
      seen.add(r.ic);
      const issues = [];
      const st = /BELUM/i.test(r.status);
      if (st) { issues.push('Belum ditaksir'); belum++; }
      const data = ctx.students[r.ic];
      KOMPONEN_KEYS.forEach((k) => {
        const inSPPB = r[k].aktiviti;
        let inData = data && PP.effectiveFor(data, null, k).aktiviti;
        if (inData === '__CLEAR__') inData = '';
        const L = KOMPONEN[k].label.split(' ')[0];
        if (!inSPPB && inData) issues.push(L + ': belum diisi (data: ' + inData + ')');
        else if (inSPPB && !r[k].skor) issues.push(L + ': tiada skor');
        else if (inSPPB && inData && inData !== '__CLEAR__' && !PP.matchFor(k, 'aktiviti', inData, [inSPPB], ctx.mapping, false, k === 'EKSTRA' && data.komponen.EKSTRA ? data.komponen.EKSTRA.perkhidmatanSkor : null).option) { issues.push(L + ': SPPB "' + inSPPB + '" ≠ data "' + inData + '"'); beza++; }
        else if (!inSPPB && !inData && !hasData && !st && !KOMPONEN[k].ekstra) issues.push(L + ': kosong');
      });
      if (hasData && !data) issues.push('Tiada dalam data import');
      if (!st && issues.length) tidakLengkap++;
      if (!issues.length) ok++;
      if (issues.length) {
        r.row.style.background = st ? 'rgba(239,68,68,.10)' : 'rgba(245,158,11,.14)';
        r.row.setAttribute('data-pp-hl', '1');
        const tag = document.createElement('div');
        tag.className = 'pp-mark';
        tag.style.cssText = 'margin-top:4px;font-size:11px;line-height:1.35;color:' + (st ? '#b91c1c' : '#92400e') + ';font-weight:600';
        tag.textContent = '⚑ ' + issues.join(' · ');
        r.row.querySelectorAll('td')[1].appendChild(tag);
        lines.push(r.bil + '. ' + r.nama + ' — ' + issues.join('; '));
      }
    });
    const extra = hasData ? Object.keys(ctx.students).filter((ic) => !seen.has(ic)) : [];
    ui.log('Semakan: ' + rows.length + ' murid · ' + ok + ' lengkap · ' + belum + ' belum ditaksir · ' + tidakLengkap + ' tidak lengkap' + (beza ? ' · ' + beza + ' aktiviti berbeza' : ''));
    if (extra.length && extra.length < 200) ui.log('ℹ ' + extra.length + ' murid dalam data import tiada dalam kelas ini (mungkin kelas lain).');
    ui.setReport(lines);
  }

  // ======================================================================
  // ISI PUKAL (giliran URL dari halaman senarai)
  // ======================================================================
  async function startBatch(opts) {
    const ctx = await loadAll();
    const rows = parseList();
    if (!rows.length) { ui.log('✖ Jadual senarai murid tidak dijumpai'); return; }
    let q = rows.filter((r) => r.url);
    if (opts.onlyData) q = q.filter((r) => ctx.students[r.ic]);
    if (opts.skipDone) q = q.filter((r) => /BELUM|SEDANG/i.test(r.status) || !r.status);
    if (!q.length) { ui.log('✖ Tiada murid untuk diisi (semak data import / penapis)'); return; }
    // Semak padanan nama sebelum mula (guna senarai pilihan SPPB yang telah direkod)
    const od = await store.get(['pp_options']);
    const cap = (od.pp_options && od.pp_options.aktiviti) || {};
    const unresolved = {};
    for (const r of q) {
      const st = ctx.students[r.ic];
      if (!st) continue;
      for (const k of KOMPONEN_KEYS) {
        const want = PP.effectiveFor(st, ctx.defaults, k).aktiviti;
        const opts = cap[k] || (k === 'EKSTRA' ? PP.PERKHIDMATAN : null);
        if (!want || !opts || want === '__CLEAR__') continue;
        const sk = k === 'EKSTRA' && st.komponen && st.komponen.EKSTRA ? st.komponen.EKSTRA.perkhidmatanSkor : null;
        if (!PP.matchFor(k, 'aktiviti', want, opts, ctx.mapping, false, sk).option) {
          const key = KOMPONEN[k].label + ': ' + want;
          unresolved[key] = (unresolved[key] || 0) + 1;
        }
      }
    }
    const ul = Object.keys(unresolved);
    if (ul.length) {
      ui.log('⚠ ' + ul.length + ' nama belum dapat dipadankan dengan pasti:');
      ul.forEach((u) => ui.log('   – ' + u + ' (' + unresolved[u] + ' murid)'));
      ui.log('   Tetapkan pemetaan di Tetapan → bahagian 3.');
      if (!confirm(ul.length + ' nama aktiviti / jawatan khas belum dipetakan (lihat Log).\n\nTekan OK untuk teruskan juga — murid berkenaan akan dijeda untuk anda isi sendiri.\nTekan Cancel untuk buka Tetapan dan petakan dahulu.')) {
        send({ type: 'openOptions' });
        return;
      }
    }
    const batch = {
      active: true, review: !!opts.review, forceDefaults: !opts.onlyData,
      listUrl: location.href, index: 0, startedAt: Date.now(),
      queue: q.map((r) => ({ url: r.url, ic: r.ic, nama: r.nama })),
      results: [], tabDone: []
    };
    await store.set({ pp_batch: batch });
    ui.log('▶ Isi pukal dimulakan: ' + q.length + ' murid');
    location.href = batch.queue[0].url;
  }

  async function stopBatch(msg) {
    const d = await store.get(['pp_batch']);
    if (d.pp_batch) { d.pp_batch.active = false; await store.set({ pp_batch: d.pp_batch }); }
    ui.log(msg || '■ Isi pukal dihentikan');
    ui.render();
  }

  // Mod rantai: guna butang "Seterusnya" SPPB untuk ke murid berikutnya
  async function chainNext(batch) {
    batch.awaitNext = true;
    await persist(batch);
    if (swalEl()) await dismissSwal(500);
    const btn = findButton('Seterusnya');
    const oldIc = readStudent().ic;
    if (!btn || btn.disabled) return chainFinish(batch, '■ Tiada murid seterusnya — selesai.');
    realClick(btn);
    // SPPB memaparkan "Amaran — … Klik OK sekiranya anda pasti untuk berganti murid".
    // Semua tab murid ini sudah disimpan, jadi tekan OK.
    let confirmed = 0;
    const ok = await waitFor(() => {
      const st = readStudent();
      if (st.ic && st.ic !== oldIc) return st;
      const pop = swalEl();
      if (pop && confirmed < 3) {
        const t = (pop.textContent || '').replace(/\s+/g, ' ').trim();
        const cb = pop.querySelector('.swal2-confirm, .swal-button--confirm, button.confirm');
        if (cb) { confirmed++; ui.log('ℹ SPPB: "' + t.slice(0, 90) + '…" → OK'); realClick(cb); }
      }
      return null;
    }, 25000, 250);
    if (!ok) return chainFinish(batch, '■ Murid seterusnya tidak dimuatkan — berhenti.');
    await sleep(STEP + 500);
    return chainArrived(batch);
  }
  async function chainArrived(batch) {
    const st = readStudent();
    batch.queue.push({ url: location.href, ic: st.ic, nama: st.nama });
    batch.awaitNext = false;
    batch.tabDone = [];
    await persist(batch);
    ui.log('▶ [murid ke-' + (batch.index + 1) + '] ' + st.nama);
    ui.render();
    const ctx = await loadAll();
    return processStudent(batch, ctx);
  }
  async function chainFinish(batch, msg) {
    if (swalEl()) await dismissSwal(500);
    batch.active = false; batch.awaitNext = false; batch.finishedAt = Date.now();
    await persist(batch);
    ui.log(msg);
    ui.render();
  }

  async function nextInBatch(batch, result) {
    batch.results.push(result);
    batch.index++;
    if (batch.chain) return chainNext(batch);
    if (batch.index >= batch.queue.length) {
      batch.active = false;
      batch.finishedAt = Date.now();
      await store.set({ pp_batch: batch });
      location.href = batch.listUrl;
      return;
    }
    await store.set({ pp_batch: batch });
    await sleep(500);
    location.href = batch.queue[batch.index].url;
  }

  // ---- Aliran isi + simpan SETIAP TAB (SPPB hanya menyimpan tab yang aktif) ----
  const PAGE_ID = Math.random().toString(36).slice(2);
  let batchRunning = false;

  function activeKomp() {
    const t = tabItems().find((x) => x.getAttribute('aria-selected') === 'true');
    return t ? KOMPONEN_KEYS.find((k) => txt(t).includes(KOMPONEN[k].tabKey)) || null : null;
  }

  async function persist(b) { await store.set({ pp_batch: b }); }

  async function pause(b, komp, kind, msg) {
    if (swalEl()) await dismissSwal(500);
    b.paused = true; b.pendingTab = komp; b.pauseKind = kind; b.pagePauseId = PAGE_ID;
    await persist(b);
    ui.log('⏸ ' + msg);
    ui.render();
  }

  async function saveTabAndMark(b, komp, ctx, optional) {
    const L = KOMPONEN[komp].label;
    ui.log('… menyimpan tab ' + L);
    const s = await saveCurrent();
    if (!s.ok && optional) {
      // tab tanpa aktiviti — kegagalan tidak menghalang murid lain
      ui.log('⚠ Tab ' + L + ' (tanpa aktiviti) tidak dapat disimpan: ' + s.msg + ' — diteruskan');
      b.tabDone.push(komp); await persist(b);
      if (swalEl()) await dismissSwal(500);
      return true;
    }
    if (!s.ok) {
      ui.log('✖ Simpan tab ' + L + ' gagal: ' + s.msg);
      if (ctx.settings.stopOnError) { await pause(b, komp, 'error', 'Betulkan tab ' + L + ', kemudian tekan "Simpan & Teruskan" (atau "Langkau tab").'); return false; }
      b.tabDone.push(komp); b.anyError = true; await persist(b);
      return true;
    }
    ui.log('✓ Tab ' + L + ' disimpan');
    b.tabDone.push(komp);
    await persist(b);
    // SPPB mungkin melukis semula borang selepas simpan — tunggu borang murid yang sama
    const ic = b.queue[b.index].ic;
    await waitFor(() => getForm() && readStudent().ic === ic, 15000);
    await sleep(STEP + 300);
    return true;
  }

  async function finishStudent(b, status, msg) {
    await dismissSwal(1200); // tutup dialog "Berjaya!" yang mungkin muncul lewat
    const item = b.queue[b.index];
    b.tabDone = []; b.anyError = false; b.paused = false; b.pendingTab = null;
    return nextInBatch(b, { ic: item.ic, nama: item.nama, status, msg });
  }

  async function processStudent(b, ctx) {
    STEP = ctx.settings.stepDelay || 250;
    const item = b.queue[b.index];
    b.tabDone = b.tabDone || [];
    const form = await waitFor(() => { const f = getForm(); return f && readStudent().ic ? f : null; }, 15000);
    if (!form) throw new Error('Borang PAJSK murid tidak dijumpai di halaman ini');
    const st = readStudent();
    if (item.ic && st.ic !== item.ic) throw new Error('No. KP di borang (' + st.ic + ') tidak sama dengan giliran (' + item.ic + ')');
    const data = ctx.students[st.ic];
    if (!data && ctx.settings.skipNoData && !b.forceDefaults) {
      ui.log('• ' + st.nama + ' tiada dalam data yang diimport — dilangkau');
      return finishStudent(b, 'langkau');
    }
    ctx.hasData = !!data;
    for (const komp of KOMPONEN_KEYS) {
      if (b.tabDone.includes(komp)) continue;
      const L = KOMPONEN[komp].label;
      const eff = PP.effectiveFor(data, ctx.defaults, komp);
      if (!Object.keys(eff).length && !data) { b.tabDone.push(komp); continue; }
      const log = [];
      let r;
      try { r = await fillKomponen(komp, eff, ctx, log); } catch (e) { r = { error: true }; log.push('✖ ' + L + ': ' + e.message); }
      log.forEach((l) => ui.log(l));
      if (r.error) {
        if (ctx.settings.stopOnError) return pause(b, komp, 'error', 'Ada ralat pada tab ' + L + '. Betulkan sendiri, kemudian "Simpan & Teruskan" (atau "Langkau tab").');
        b.tabDone.push(komp); b.anyError = true; await persist(b);
        continue;
      }
      if (!r.filled && !r.switched) { b.tabDone.push(komp); await persist(b); continue; }
      if (b.review && !r.optional) return pause(b, komp, 'review', 'Semak tab ' + L + '. Tekan "Simpan & Teruskan" atau "Langkau tab".');
      if (!(await saveTabAndMark(b, komp, ctx, r.optional))) return;
    }
    return finishStudent(b, b.anyError ? 'sebahagian' : 'disimpan');
  }

  async function resumeBatchIfAny() {
    if (batchRunning) return;
    const ctx = await loadAll();
    const b = ctx.batch;
    if (!b || !b.active) return;
    if (b.chain && b.awaitNext && pageType() === 'FORM') {
      batchRunning = true;
      ui.open();
      try { await waitFor(() => readStudent().ic, 15000); await chainArrived(b); } catch (e) { ui.log('✖ ' + e.message); } finally { batchRunning = false; }
      return;
    }
    const item = b.queue[b.index];
    if (!item) return;
    const here = location.pathname.replace(/\/$/, '');
    const target = new URL(item.url, location.href).pathname.replace(/\/$/, '');
    if (pageType() !== 'FORM' || here !== target) return;
    // Dijeda pada halaman lain (halaman dimuat semula) — isian belum disimpan sudah hilang, isi semula tab itu
    if (b.paused) { if (b.pagePauseId === PAGE_ID) return; b.paused = false; await persist(b); }
    batchRunning = true;
    ui.open(); ui.render();
    if (!b.tabDone || !b.tabDone.length) ui.log('▶ [' + (b.index + 1) + (b.chain ? '' : '/' + b.queue.length) + '] ' + item.nama);
    try {
      await processStudent(b, ctx);
    } catch (e) {
      ui.log('✖ ' + e.message);
      await pause(b, b.pendingTab || null, 'error', 'Isi pukal dijeda.');
    } finally {
      batchRunning = false;
    }
  }

  // save=true: simpan tab yang dijeda; save=false: langkau tab itu; 'student': langkau murid
  async function batchContinue(save) {
    if (batchRunning) return;
    const ctx = await loadAll();
    const b = ctx.batch;
    if (!b || !b.active) return;
    if (b.pagePauseId !== PAGE_ID) { b.paused = false; await persist(b); return resumeBatchIfAny(); }
    batchRunning = true;
    try {
      b.paused = false;
      const komp = b.pendingTab;
      b.tabDone = b.tabDone || [];
      if (save === 'student') { ui.log('• Murid dilangkau'); return await finishStudent(b, 'langkau (manual)'); }
      if (komp) {
        if (save) {
          if (activeKomp() !== komp) await switchTab(komp);
          if (!(await saveTabAndMark(b, komp, ctx))) return;
        } else {
          b.tabDone.push(komp); b.anyError = true;
          ui.log('• Tab ' + KOMPONEN[komp].label + ' dilangkau (tidak disimpan)');
          await persist(b);
        }
      }
      await processStudent(b, ctx);
    } catch (e) {
      ui.log('✖ ' + e.message);
    } finally {
      batchRunning = false;
    }
  }

  // ======================================================================
  // PANEL UI (Shadow DOM)
  // ======================================================================
  const ui = (() => {
    let host, root, logEl, bodyEl, reportEl, isOpen = false, renderSeq = 0;
    const CSS_TEXT = `
      :host{all:initial}
      *{box-sizing:border-box;font-family:system-ui,-apple-system,"Segoe UI",Roboto,sans-serif}
      .fab{position:fixed;right:18px;bottom:18px;z-index:2147483000;width:52px;height:52px;border-radius:16px;border:0;cursor:pointer;
        background:#0f5132;color:#fff;font:700 13px/1 system-ui;box-shadow:0 6px 20px rgba(0,0,0,.25);letter-spacing:.3px}
      .fab:hover{background:#0b3d26}
      .panel{position:fixed;right:18px;bottom:80px;z-index:2147483000;width:360px;max-height:calc(100vh - 110px);display:none;flex-direction:column;
        background:#fff;color:#1f2937;border-radius:14px;box-shadow:0 12px 40px rgba(0,0,0,.28);overflow:hidden;font-size:13px}
      .panel.open{display:flex}
      .hd{background:#0f5132;color:#fff;padding:10px 14px;display:flex;align-items:center;gap:8px}
      .hd b{font-size:14px;flex:1}
      .hd .x{background:transparent;border:0;color:#fff;font-size:18px;cursor:pointer;line-height:1}
      .sub{font-size:11px;opacity:.85;font-weight:400}
      .bd{padding:12px 14px;overflow:auto;display:flex;flex-direction:column;gap:10px}
      .card{border:1px solid #e5e7eb;border-radius:10px;padding:10px}
      .card h4{margin:0 0 6px;font-size:12px;text-transform:uppercase;letter-spacing:.4px;color:#6b7280}
      .row{display:flex;gap:6px;flex-wrap:wrap}
      button.b{border:1px solid #d1d5db;background:#f9fafb;color:#111827;border-radius:8px;padding:7px 10px;font-size:12.5px;cursor:pointer;font-weight:600}
      button.b:hover{background:#f3f4f6}
      button.p{background:#0f5132;border-color:#0f5132;color:#fff}
      button.p:hover{background:#0b3d26}
      button.w{background:#fff7ed;border-color:#fdba74;color:#9a3412}
      button.d{background:#fef2f2;border-color:#fca5a5;color:#991b1b}
      button:disabled{opacity:.5;cursor:default}
      label.c{display:flex;gap:6px;align-items:flex-start;font-size:12.5px;margin:3px 0;cursor:pointer}
      .muted{color:#6b7280;font-size:12px}
      .log{background:#0b1220;color:#d1fae5;font:12px/1.45 ui-monospace,Menlo,Consolas,monospace;border-radius:8px;padding:8px;max-height:200px;overflow:auto;white-space:pre-wrap;word-break:break-word}
      .rep{max-height:160px;overflow:auto;font-size:12px;line-height:1.4}
      .rep div{padding:3px 0;border-bottom:1px dashed #e5e7eb}
      .prog{height:6px;background:#e5e7eb;border-radius:4px;overflow:hidden}
      .prog i{display:block;height:100%;background:#16a34a}
      a{color:#0f5132}
    `;

    function el(tag, attrs, ...kids) {
      const e = document.createElement(tag);
      for (const k in attrs || {}) {
        if (k === 'on') for (const ev in attrs.on) e.addEventListener(ev, attrs.on[ev]);
        else if (k === 'class') e.className = attrs[k];
        else if (k in e && typeof attrs[k] !== 'string') e[k] = attrs[k];
        else e.setAttribute(k, attrs[k]);
      }
      kids.flat().forEach((c) => c != null && e.append(c.nodeType ? c : document.createTextNode(String(c))));
      return e;
    }

    function mount() {
      if (host && document.documentElement.contains(host)) return;
      host = document.createElement('div');
      host.id = 'pajsk-pembantu-host';
      document.documentElement.appendChild(host);
      root = host.attachShadow({ mode: 'open' });
      root.append(el('style', {}, CSS_TEXT));
      const fab = el('button', { class: 'fab', title: 'PAJSK Pembantu', on: { click: () => toggle() } }, 'PAJSK');
      bodyEl = el('div', { class: 'bd' });
      logEl = el('div', { class: 'log' });
      reportEl = el('div', { class: 'rep' });
      const panel = el('div', { class: 'panel' },
        el('div', { class: 'hd' }, el('b', {}, 'PAJSK Pembantu ', el('span', { class: 'sub' }, 'v' + (() => { try { return chrome.runtime.getManifest().version; } catch (e) { return ''; } })())),
          el('button', { class: 'x', title: 'Tutup', on: { click: () => toggle(false) } }, '×')),
        bodyEl);
      root.append(panel, fab);
    }

    function toggle(force) {
      mount();
      isOpen = force == null ? !isOpen : force;
      root.querySelector('.panel').classList.toggle('open', isOpen);
      if (isOpen) render();
      try { sessionStorage.setItem('pp_open', isOpen ? '1' : '0'); } catch (e) {}
    }

    function log(m) {
      mount();
      const t = new Date().toTimeString().slice(0, 8);
      logEl.textContent += (logEl.textContent ? '\n' : '') + t + '  ' + m;
      logEl.scrollTop = logEl.scrollHeight;
    }

    function setReport(lines) {
      reportEl.innerHTML = '';
      if (!lines.length) { reportEl.append(el('div', {}, '✓ Semua murid lengkap.')); return; }
      lines.forEach((l) => reportEl.append(el('div', {}, l)));
    }

    function optBox(id, label, checked) {
      return el('label', { class: 'c' }, el('input', { type: 'checkbox', id, checked: !!checked }), el('span', {}, label));
    }

    async function render() {
      mount();
      const ctx = await loadAll();
      const pt = pageType();
      const n = Object.keys(ctx.students).length;
      const b = ctx.batch;
      // Elak paparan berganda: render() tak segerak boleh dipanggil dua kali serentak.
      // Bina dalam bekas berasingan, dan hanya panggilan TERAKHIR yang menggantikan panel.
      const seq = ++renderSeq;
      const out = document.createElement('div');

      const dataCard = el('div', { class: 'card' }, el('h4', {}, 'Data murid'),
        n ? el('div', {}, el('b', {}, n + ' murid'), ' dimuatkan', ctx.meta && ctx.meta.fileName ? el('div', { class: 'muted' }, ctx.meta.fileName) : '')
          : el('div', { class: 'muted' }, 'Belum ada data diimport. Isi pukal tetap boleh guna nilai lalai.'),
        ctx.meta && ctx.meta.slip ? el('div', { style: 'font-size:11.5px;color:#0f5132;font-weight:600;margin-top:2px' }, '✓ Slip Infomurid — SPPB diselaraskan ikut skor slip') : '',
        el('div', { class: 'row', style: 'margin-top:6px' },
          el('button', { class: 'b p', title: 'Buka Tetapan untuk import fail slip.xls', on: { click: () => send({ type: 'openOptions' }) } }, '📥 Import Slip Infomurid Kelas'),
          el('button', { class: 'b', on: { click: () => send({ type: 'openOptions' }) } }, '⚙ Tetapan')));
      out.append(dataCard);

      const upd = await new Promise((res) => send({ type: 'checkUpdate', force: false }, res));
      if (upd && upd.hasUpdate) {
        const notes = Array.isArray(upd.info.notes) ? upd.info.notes : (upd.info.notes ? [upd.info.notes] : []);
        out.insertBefore(el('div', { class: 'card', style: 'background:#fffbeb;border-color:#fcd34d;color:#78350f' },
          el('h4', { style: 'color:#92400e' }, '🔔 Versi ' + upd.latest + ' tersedia (anda: ' + upd.current + ')'),
          ...notes.slice(0, 4).map((n) => el('div', { style: 'font-size:12px' }, '• ' + n)),
          el('div', { class: 'row', style: 'margin:6px 0' }, el('button', { class: 'b w', on: { click: () => send({ type: 'openUrl', url: upd.info.zip }) } }, '⬇ Muat turun versi baharu')),
          el('div', { style: 'font-size:11.5px' }, 'Unzip & ganti fail dalam folder lama → chrome://extensions → ↻ Reload → F5 halaman ini.')), dataCard);
      }

      if (b && b.active) {
        const pct = Math.round((b.index / b.queue.length) * 100);
        const c = el('div', { class: 'card' }, el('h4', {}, b.single ? 'Mengisi & menyimpan murid ini' : b.chain ? 'Isi automatik (murid ini & seterusnya)' : 'Isi pukal sedang berjalan'),
          el('div', {}, (b.single ? '' : b.chain ? 'Murid ke-' + (b.index + 1) : (b.index + 1 > b.queue.length ? b.queue.length : b.index + 1) + ' / ' + b.queue.length) +
            ' · tab disimpan: ' + ((b.tabDone || []).map((k) => KOMPONEN[k].label.split(' ')[0]).join(', ') || '—') + (b.paused ? ' — DIJEDA' + (b.pendingTab ? ' di tab ' + KOMPONEN[b.pendingTab].label : '') : '')),
          b.chain ? '' : el('div', { class: 'prog', style: 'margin:6px 0' }, el('i', { style: 'width:' + pct + '%' })),
          el('div', { class: 'row' },
            b.paused ? el('button', { class: 'b p', on: { click: () => batchContinue(true) } }, '💾 Simpan & Teruskan') : '',
            b.paused && b.review ? el('button', { class: 'b p', title: 'Simpan tab ini dan teruskan semua tab & murid seterusnya tanpa berhenti', on: { click: async () => { b.review = false; await persist(b); batchContinue(true); } } }, '⏩ Simpan & Auto (tanpa jeda)') : '',
            !b.paused && !b.review && !b.single ? el('button', { class: 'b', title: 'Berhenti untuk semakan selepas tab yang sedang diisi', on: { click: async () => { const d = await store.get(['pp_batch']); if (d.pp_batch) { d.pp_batch.review = true; await persist(d.pp_batch); ui.log('ℹ Akan dijeda pada tab seterusnya'); } } } }, '⏸ Jeda untuk semak') : '',
            b.paused ? el('button', { class: 'b', on: { click: () => batchContinue(false) } }, 'Langkau tab') : '',
            b.paused && !b.single ? el('button', { class: 'b', on: { click: () => batchContinue('student') } }, 'Langkau murid') : '',
            el('button', { class: 'b d', on: { click: () => stopBatch() } }, '■ Henti')));
        out.append(c);
      } else if (b && b.finishedAt && b.results && b.results.length && !b.shown) {
        const s = b.results.filter((r) => r.status === 'disimpan').length;
        const g = b.results.filter((r) => r.status === 'gagal' || r.status === 'sebahagian');
        const c = el('div', { class: 'card' }, el('h4', {}, b.single ? 'Keputusan: ' + b.results[0].nama : 'Keputusan isi pukal terakhir'),
          el('div', {}, s + ' disimpan sepenuhnya · ' + (b.results.length - s - g.length) + ' dilangkau · ' + g.length + ' tidak lengkap'),
          ...g.map((x) => el('div', { class: 'muted' }, '⚠ ' + x.nama + (x.msg ? ': ' + x.msg : ' — ada tab yang dilangkau/gagal'))),
          el('div', { class: 'row', style: 'margin-top:6px' }, el('button', { class: 'b', on: { click: async () => { b.shown = true; await store.set({ pp_batch: b }); render(); } } }, 'Tutup ringkasan')));
        out.append(c);
      }

      if (pt === 'LIST') {
        out.append(el('div', { class: 'card' }, el('h4', {}, 'Senarai murid kelas'),
          el('div', { class: 'row' },
            el('button', { class: 'b', on: { click: exportList } }, '⬇ Eksport CSV'),
            el('button', { class: 'b', on: { click: checkList } }, '🔍 Semak data'),
            el('button', { class: 'b', on: { click: () => { clearMarks(); reportEl.innerHTML = ''; } } }, 'Buang tanda')),
          reportEl));
        if (!(b && b.active)) {
          const card = el('div', { class: 'card' }, el('h4', {}, 'Isi pukal satu kelas'),
            optBox('pp-onlydata', 'Hanya murid yang ada dalam data import', n > 0),
            optBox('pp-skipdone', 'Langkau murid yang statusnya sudah selesai', true),
            optBox('pp-review', 'Jeda pada setiap tab untuk saya semak sebelum disimpan', false),
            el('div', { class: 'muted', style: 'margin:4px 0 6px' }, 'Bagi setiap murid, extension mengisi satu tab, menekan Simpan, kemudian beralih ke tab seterusnya — sebelum ke murid berikutnya.'),
            el('button', { class: 'b p', on: { click: () => startBatch({
              onlyData: root.getElementById('pp-onlydata').checked,
              skipDone: root.getElementById('pp-skipdone').checked,
              review: root.getElementById('pp-review').checked }) } }, '▶ Mula isi pukal'));
          out.append(card);
        }
      } else if (pt === 'FORM') {
        const st = readStudent();
        const has = st.ic && ctx.students[st.ic];
        const card = el('div', { class: 'card' }, el('h4', {}, 'Murid ini'),
          el('div', {}, st.nama || '—', el('div', { class: 'muted' }, st.ic ? st.ic + (has ? ' · ada dalam data ✓' : ' · tiada dalam data (guna nilai lalai)') : 'Menunggu borang…')),
          el('div', { class: 'row', style: 'margin-top:6px' },
            el('button', { class: 'b p', disabled: !!(b && b.active), on: { click: () => runFill(true) } }, '💾 Isi & Simpan semua tab'),
            el('button', { class: 'b', disabled: !!(b && b.active), on: { click: () => runFill(false) } }, '✎ Isi tab ini sahaja')),
          el('div', { class: 'row', style: 'margin-top:6px' },
            el('button', { class: 'b p', disabled: !!(b && b.active), title: 'Isi & simpan semua tab, tekan Seterusnya, ulang sehingga murid terakhir', on: { click: () => runFill(true, true) } }, '⏩ Isi & simpan murid ini dan seterusnya')),
          el('div', { class: 'muted', style: 'margin-top:6px' }, 'SPPB hanya menyimpan tab yang sedang dibuka — "Isi & Simpan semua tab" mengisi dan menyimpan setiap tab satu demi satu.'),
          el('div', { class: 'muted', style: 'margin-top:6px' }, 'Isi pukal satu kelas dimulakan dari halaman Senarai Murid.'));
        out.append(card);
      } else {
        out.append(el('div', { class: 'card muted' }, 'Buka Keputusan → PAJSK → pilih kelas untuk guna extension ini.'));
      }

      if (seq !== renderSeq) return;
      out.append(el('div', { class: 'card' }, el('h4', {}, 'Log'), logEl));
      bodyEl.replaceChildren(...out.childNodes);
    }

    function open() { toggle(true); }
    return { mount, toggle, open, log, render, setReport };
  })();

  // andSave=true: isi & simpan semua tab murid ini (satu demi satu)
  // andSave=false: isi tab yang sedang dibuka sahaja (tanpa simpan) untuk disemak
  async function runFill(andSave, chain) {
    const ctx = await loadAll();
    if (andSave) {
      const st = readStudent();
      if (!st.ic) { ui.log('✖ Borang murid belum dimuatkan'); return; }
      const b = { active: true, single: !chain, chain: !!chain, review: false, forceDefaults: !chain, listUrl: location.href, index: 0,
        startedAt: Date.now(), queue: [{ url: location.href, ic: st.ic, nama: st.nama }], results: [], tabDone: [] };
      await persist(b);
      return resumeBatchIfAny();
    }
    STEP = ctx.settings.stepDelay || 250;
    const komp = activeKomp();
    if (!komp) { ui.log('✖ Tab aktif tidak dikenal pasti'); return; }
    const st = readStudent();
    const data = ctx.students[st.ic];
    ctx.hasData = !!data;
    ui.log('▶ Mengisi tab ' + KOMPONEN[komp].label + '…');
    const log = [];
    try {
      const r = await fillKomponen(komp, PP.effectiveFor(data, ctx.defaults, komp), ctx, log);
      log.forEach((l) => ui.log(l));
      ui.log(r.error ? '⚠ Ada ralat — betulkan sebelum simpan' : 'ℹ Semak tab ini dan tekan Simpan SEBELUM bertukar tab (isian tab lain tidak disimpan).');
    } catch (e) { ui.log('✖ ' + e.message); }
  }

  // ======================================================================
  // Mula
  // ======================================================================
  chrome.runtime.onMessage.addListener((msg) => {
    if (msg && msg.type === 'togglePanel') ui.toggle();
  });

  let lastPath = '';
  function onRoute() {
    if (location.pathname === lastPath) return;
    lastPath = location.pathname;
    const pt = pageType();
    if (pt === 'OTHER') return;
    ui.mount();
    let wasOpen = false;
    try { wasOpen = sessionStorage.getItem('pp_open') === '1'; } catch (e) {}
    if (wasOpen) ui.open(); else ui.render();
    setTimeout(resumeBatchIfAny, 1200);
  }
  onRoute();
  var routeTimer = setInterval(() => { if (alive()) onRoute(); }, 800);

  // untuk ujian
  window.__PP_TEST__ = { processStudent, saveCurrent, parseList, checkList, exportList, loadAll, readStudent };
})();
